#pragma once

#include <string>

#define literal static constexpr const

namespace cchar {
	literal std::string LAMBDA = "\u03BB";
	literal std::string MU = "\u03BC";
}

namespace paths::model {
	literal auto Q  = "logs/Models/Q.log";
	literal auto A  = "logs/Models/A.log";
	literal auto B  = "logs/Models/B.log";
	literal auto C1 = "logs/Models/C1.log";
	literal auto C2 = "logs/Models/C2.log";
	literal auto C3 = "logs/Models/C3.log";
	literal auto C4 = "logs/Models/C4.log";
	literal auto C5 = "logs/Models/C5.log";
}

namespace paths::parse {
	literal auto Q  = "logs/Parse/Q.log";
	literal auto A  = "logs/Parse/A.log";
	literal auto B  = "logs/Parse/B.log";
	literal auto C1 = "logs/Parse/C1.log";
	literal auto C2 = "logs/Parse/C2.log";
	literal auto C3 = "logs/Parse/C3.log";
	literal auto C4 = "logs/Parse/C4.log";
	literal auto C5 = "logs/Parse/C5.log";
}

#undef literal
