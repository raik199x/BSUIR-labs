#pragma once

#include <string>
#include <vector>

#include <interface/consts.hpp>

#define literal static constexpr const

namespace literals::app {
	literal auto title = "Modelling - Lab 4 - Mass service systems";
}

namespace literals::request {
	literal auto prompt = "Task 8";
	static const std::vector<std::string> prompts = {
		cchar::LAMBDA.c_str(),
		"Average time of channel handling, (hours)",
		"The cost of 1 channel ($ per hour)",
		"The cost of 1 place in a queue ($ per hour)",
		"The revenue for 1 handled request ($ per request)",
	};
	static const std::vector<std::string> values = {
		"4",
		"0.8",
		"2",
		"0.3",
		"4",
	};
	literal auto emulate = "Emulate";
	literal auto process = "Emulating...";
}

namespace literals::response {
	literal auto prompt = "Total revenue, $";
	static const std::vector<std::string> prompts = {
		"No queue, 2 channels",
		"No queue, 3 channels",
		"Queue (VAR N), 2 channels (maximum)",
	};
}

#undef literal
