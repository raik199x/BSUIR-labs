#pragma once

#include <fstream>
#include <iostream>

#define log_open(file) \
	logfile.open(file); \
	if (!logfile.is_open()) \
		throw std::runtime_error("Could not open logfile"); \
	backup = std::clog.rdbuf(); \
	std::clog.rdbuf(logfile.rdbuf())
#define log_init(file) \
	std::ofstream logfile; \
	std::streambuf* backup; \
	log_open(file)
#define log_close() \
	std::clog.rdbuf(backup); \
	logfile.close()
#define log_reopen(file) \
	log_close(); \
	log_open(file)
