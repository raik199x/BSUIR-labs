#pragma once

#include <iostream>

#include <backend/Models.hpp>

template <const usize Q>
void queueing(void) {
	std::clog << "--- Queue testcase (Queue <" << Q << ">) ---" << std::endl;
	Queue<Q> q;
	for (usize i = 0; i < Q; ++i) {
		std::clog << q << ' ';
		q.push();
	}
	std::clog << q;
	for (usize i = 0; i < Q; ++i) {
		q.pop();
		std::clog << ' ' << q;
	}
	std::clog << std::endl;
}

template <const usize N>
void unqueuedModelling(const std::string_view& name) {
	std::clog << "--- Full transition table for the model " << name << " (Unqueued<" << N << ", " << 0 << ">) ---" << std::endl;
	UnqueuedModel<N> model;
	for (usize state = 0u; state < (1u << N); ++state) {
		for (usize action = 0u; action < (1u << N); ++action) {
			const Actions<N> actions = to_actions<N>(action);
			if (!actions.at(0)) { continue; }
			const Actions<N> states = to_actions<N>(state);
			Devices<N> devices;
			for (usize i = 0; i < N; ++i) {
				devices[i] = {
					.state = states[i] ? Device::State::BUSY : Device::State::FREE,
					.policy = i == 0 ? Device::Policy::DISCARD : Device::Policy::UNKNOWN,
				};
			}
			model.set_devices(devices);
			std::clog << model << " -[" << actions << "]-> ";
			model.shift(actions);
			std::clog << model << std::endl;
		}
	}
}

template <const usize Q>
void queuedModelling(const std::string_view& name) {
	static constexpr const usize N = 3;
	std::clog << "--- Full transition table for the model " << name << " (Queued<" << N << ", " << Q << ">) ---" << std::endl;
	QueuedModel<Q> model;
	for (usize queue = 0u; queue <= Q; ++queue) {
		for (usize state = 0u; state < (1u << N); ++state) {
			for (usize action = 0u; action < (1u << N); ++action) {
				const Actions<N> actions = to_actions<N>(action);
				if (!actions.at(0)) { continue; }
				const Actions<N> states = to_actions<N>(state);
				Devices<N> devices;
				for (usize i = 0; i < N; ++i) {
					devices[i] = {
						.state = states[i] ? Device::State::BUSY : Device::State::FREE,
						.policy = i == 0 ? Device::Policy::DISCARD : Device::Policy::UNKNOWN,
					};
				}
				model.set_devices(devices);
				model.set_queue(Queue<Q>(queue));
				std::clog << model << " -[" << actions << "]-> ";
				model.shift(actions);
				std::clog << model << std::endl;
			}
		}
	}
}
