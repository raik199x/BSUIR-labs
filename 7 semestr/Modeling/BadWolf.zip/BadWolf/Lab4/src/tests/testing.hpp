#pragma once

#include <interface/consts.hpp>
#include <interface/logging.hpp>

#include <tests/Testing.hpp>

namespace testing {
	void interface(void) {
		log_init(paths::model::Q);		queueing<25>();
		log_reopen(paths::model::A);	unqueuedModelling<3u>("A");
		log_reopen(paths::model::B);	unqueuedModelling<4u>("B");
		log_reopen(paths::model::C1);	queuedModelling<1u>("C1");
		log_reopen(paths::model::C2);	queuedModelling<2u>("C2");
		log_reopen(paths::model::C3);	queuedModelling<3u>("C3");
		log_reopen(paths::model::C4);	queuedModelling<4u>("C4");
		log_reopen(paths::model::C5);	queuedModelling<5u>("C5");
		log_close();
	}
}
