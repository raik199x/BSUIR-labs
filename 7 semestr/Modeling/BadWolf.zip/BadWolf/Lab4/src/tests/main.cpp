#include <tests/testing.hpp>

#define UnitTest(suit, test) UnitTest ## _ ## suit ## _ ## test
#define newUnitTest(suit, test) void UnitTest(suit, test)(void)

newUnitTest(Unit, 1) {
	static constexpr const u64 HOURS = 100llu;
	static constexpr const u64 MINS = HOURS * 60llu;
	u64 result;
	u64 source_delay = 0u;
	u64 channel_delay = 0u;
	UnqueuedModel<4> model;
	Actions<4> flags = {};
	Devices<4> devices = {};
	for (u64 mins = 0; mins < MINS + 2llu; ++mins) {
		if (source_delay == 0) {
			// trigger source
			devices = model.get_devices();
			devices.at(0).state = Device::State::BUSY;
			model.set_devices(devices);
			source_delay = 10;
		}
		--source_delay;
		flags.at(0) = true;
		model.shift(flags);
		flags = {};
		result += model.handled;
		model.handled = 0;
		if (channel_delay == 0) {
			// trigger channels
			flags.fill(true);
			channel_delay = 30;
		}
		--channel_delay;
	}
	std::cout << "result: " << result << std::endl;
}

int main(void) {
	testing::interface();
	UnitTest(Unit, 1)();
	return 0;
}
