#pragma once

#include <QMainWindow>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>

#include <common/core/types.hpp>
#include <common/core/Timer.hpp>
#include <common/interface/OptionsWidget.hpp>

#include <libs/qcustomcustomplot/newCustomPlot.hpp>

struct ComputationsConfig {
	usize hours = 100000;
	f64 lambda = 0.0;
	f64 channel_avg_time = 0.0;
	f64 channel_cost = 0.0;
	f64 queue_place_cost = 0.0;
	f64 request_revenue = 0.0;
};
struct ComputationsResult {
	ComputationsConfig request;
	struct {
		usize channels = 0u;
		usize queue_places = 0u;
		f64 handled = 0.0;
	} a, b, c[20];
};

class MainWindow : public QMainWindow {
	Q_OBJECT
public:
	MainWindow(QWidget* const parent = nullptr);
	~MainWindow(void);
private:
	// Timer
	Timer timer;
	// Central components
	struct {
		QWidget* widget = nullptr;
		QVBoxLayout* layout = nullptr;
	} central;
	// Request
	struct {
		QVBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		OptionsWidget* widget = nullptr;
		QPushButton* button = nullptr;
	} request;
	// Response
	struct {
		QVBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		OptionsWidget* widget = nullptr;
	} response;
	// Plot
	QCustomPlot* plot = nullptr;
signals:
	void computations_signal(ComputationsResult*);
private slots:
	void request_button_slot(void);
	void computations_slot(ComputationsResult*);
private:
	ComputationsResult* computations_function(const ComputationsConfig config);
	void analysis(ComputationsResult* const results);
};
