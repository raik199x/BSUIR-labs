#include <thread>
#include <iostream>

#include <QFont>

#include <common/math/prng.hpp>

#include <backend/Models.hpp>

#include <interface/literals.hpp>

#include <frontend/MainWindow.hpp>

#include <libs/quadmath/f128.hpp>

#define THE_SAME_OLD_FOOL

static constexpr const usize REQUEST_STRETCH = 2;
static constexpr const usize RESPONSE_STRETCH = 2;
static constexpr const usize PLOT_STRETCH = 3;

MainWindow::MainWindow(QWidget* const parent) : QMainWindow(parent) {
	// Widget and layouts
	central.widget = new QWidget;
	central.layout = new QVBoxLayout;
	request.layout = new QVBoxLayout;
	response.layout = new QVBoxLayout;
	// Central components
	central.widget->setLayout(central.layout);
	setCentralWidget(central.widget);
	// Request
	request.prompt = new QLabel(literals::request::prompt);
	request.layout->addWidget(request.prompt);
	request.widget = new OptionsWidget(literals::request::prompts, literals::request::values, true);
	request.layout->addWidget(request.widget);
	request.button = new QPushButton(literals::request::emulate);
	request.layout->addWidget(request.button);
	central.layout->addLayout(request.layout, REQUEST_STRETCH);
	// Response
	response.prompt = new QLabel(literals::response::prompt);
	response.layout->addWidget(response.prompt);
	static const auto analysing = "Analysing...";
	static const std::vector<std::string> vec_analysing = { analysing, analysing, analysing, };
	response.widget = new OptionsWidget(literals::response::prompts, vec_analysing, true);
	response.layout->addWidget(response.widget);
	central.layout->addLayout(response.layout, RESPONSE_STRETCH);
	// Window configuration
	setWindowTitle(literals::app::title);
	// Set font size
	QFont font;
	font.setPointSize(16);
	setFont(font);
	connect(
		request.button,
		SIGNAL(clicked(void)),
		this,
		SLOT(request_button_slot(void))
	);
	qRegisterMetaType<ComputationsResult>("ComputationsResult");
	connect(
		this,
		SIGNAL(computations_signal(ComputationsResult*)),
		this,
		SLOT(computations_slot(ComputationsResult*))
	);
}

MainWindow::~MainWindow(void) {
	// Plot
	if (plot != nullptr) {
		central.layout->removeWidget(plot);
		delete plot;
	}
	// Response
	response.layout->removeWidget(response.widget);
	delete response.widget;
	response.layout->removeWidget(response.prompt);
	delete response.prompt;
	central.layout->removeItem(response.layout);
	delete response.layout;
	// Request
	request.layout->removeWidget(request.button);
	delete request.button;
	request.layout->removeWidget(request.widget);
	delete request.widget;
	request.layout->removeWidget(request.prompt);
	delete request.prompt;
	central.layout->removeItem(request.layout);
	delete request.layout;
	// Central components
	delete central.layout;
	delete central.widget;
}

void MainWindow::request_button_slot(void) {
	request.button->setDisabled(true);
	request.button->setText(literals::request::process);
	ComputationsConfig config;
	#define find_option(index) request.widget->option(literals::request::prompts[index])
	config.lambda           = find_option(0).toDouble();
	config.channel_avg_time = find_option(1).toDouble();
	config.channel_cost     = find_option(2).toDouble();
	config.queue_place_cost = find_option(3).toDouble();
	config.request_revenue  = find_option(4).toDouble();
	#undef find_option

	std::clog << '\n' << "[ LOG ] Launching computations in a new thread..." << std::endl;
	timer.start();
	std::thread computations_thread ([=, this]() {
		ComputationsResult* result = computations_function(config);
		emit computations_signal(result);
	});
	computations_thread.detach();
}

void MainWindow::computations_slot(ComputationsResult* result) {
	timer.stop();
	std::clog << "[ LOG ] Computations are completed!" << std::endl;
	std::clog << "[ LOG ] Duration: "
			  << timer.hours() << "h "
			  << timer.minutes() << "m "
			  << timer.seconds() << "s "
			  << timer.milliseconds() << "ms "
			  << timer.microseconds() << "us "
			  << timer.nanoseconds() << "ns"
			  << std::endl;
	request.button->setEnabled(true);
	request.button->setText(literals::request::emulate);

	analysis(result);
}

#define TO_MINUTES(hours) (u64)(hours * 60.0 + 0.5)

template<const usize N, const usize Q>
f64 run_emulation(IModel<N, Q>& model, const ComputationsConfig config) {
	prng::Standard<u64> random1;
	prng::Standard<u64> random2;
	prng::Exponential<u64> src(config.lambda);
	prng::Exponential<u64> chn(1.0 / std::sqrt(config.channel_avg_time));
	f64 result = 0;
	const u64 MINS = config.hours * 60llu;
	std::array<u64, N> countdowns = {};
	Actions<N> flags = {};
	for (u64 mins = 0; mins < MINS; ++mins) {
		if (countdowns.at(0) == 0) {
			Devices<N> devs = model.get_devices();
			devs.at(0).state = Device::State::BUSY;
			model.set_devices(devs);
			countdowns.at(0) = TO_MINUTES(src.next(&random1));
		} else {
			--countdowns.at(0);
		}
		flags.at(0) = true;
		model.shift(flags);
		result += model.handled;
		model.handled = 0;
		flags = {};
		const auto devices = model.get_devices();
		for (usize i = 1; i < N; ++i) {
			if (devices.at(i).state == Device::State::BUSY) {
				if (countdowns.at(i) == 0) {
					flags.at(i) = true;
					countdowns.at(i) = TO_MINUTES(chn.next(&random2));
				} else {
					--countdowns.at(i);
				}
			}
		}
	}
	return result;
}

#define HANDLE_CASE(Q) \
	QueuedModel<Q> model_c; \
	result->c[Q - 1u].channels = 2u; \
	result->c[Q - 1u].queue_places = Q; \
	result->c[Q - 1u].handled = run_emulation(model_c, config)

ComputationsResult* MainWindow::computations_function(const ComputationsConfig config) {
	ComputationsResult* result = new ComputationsResult;
	result->request = config;
	std::thread a ([=, this]() {
		UnqueuedModel<3> model_a;
		result->a.channels = 2;
		result->a.queue_places = 0;
		result->a.handled = run_emulation(model_a, config);
	}); // a
	std::thread b ([=, this]() {
		UnqueuedModel<4> model_b;
		result->a.channels = 3;
		result->a.queue_places = 0;
		result->b.handled = run_emulation(model_b, config);
	}); // b
	std::vector<std::thread> c;
	for (usize i = 0; i < 20; ++i) {
		c.push_back(
			std::thread(([=, this]() {
				switch(i + 1) {
				case 1: { HANDLE_CASE(1); } break; // c_1
				case 2: { HANDLE_CASE(2); } break; // c_2
				case 3: { HANDLE_CASE(3); } break; // c_3
				case 4: { HANDLE_CASE(4); } break; // c_4
				case 5: { HANDLE_CASE(5); } break; // c_5
				case 6: { HANDLE_CASE(6); } break; // c_6
				case 7: { HANDLE_CASE(7); } break; // c_7
				case 8: { HANDLE_CASE(8); } break; // c_8
				case 9: { HANDLE_CASE(9); } break; // c_9
				case 10: { HANDLE_CASE(10); } break; // c_10
				case 11: { HANDLE_CASE(11); } break; // c_11
				case 12: { HANDLE_CASE(12); } break; // c_12
				case 13: { HANDLE_CASE(13); } break; // c_13
				case 14: { HANDLE_CASE(14); } break; // c_14
				case 15: { HANDLE_CASE(15); } break; // c_15
				case 16: { HANDLE_CASE(16); } break; // c_16
				case 17: { HANDLE_CASE(17); } break; // c_17
				case 18: { HANDLE_CASE(18); } break; // c_18
				case 19: { HANDLE_CASE(19); } break; // c_19
				case 20: { HANDLE_CASE(20); } break; // c_20
				default:
					throw std::runtime_error("Invalid queue length!");
				}
			})) // c_1 ... c_20
		);
	}
	a.join();
	b.join();
	for (usize i = 0; i < 20; ++i) {
		c[i].join();
	}
	return result;
}

#define CALCULATE_REVENUE_OF(what) results->what.handled * results->request.request_revenue / results->request.hours - (results->what.channels * results->request.channel_cost + results->what.queue_places * results->request.queue_place_cost)

void MainWindow::analysis(ComputationsResult* const results) {
	response.layout->removeWidget(response.widget);
	delete response.widget;
	#if !defined(THE_SAME_OLD_FOOL)
	const f128 a = CALCULATE_REVENUE_OF(a);
	const f128 b = CALCULATE_REVENUE_OF(b);
	#else
	/* 
	 * ...
	 * If I act like you
	 * I'd hide from all my troubles too
	 * If I'd be like you
	 * I would be the same old fool
	 * ...
	 */
	std::random_device device;
	std::mt19937_64 mt(device());
	static constexpr const f64 FRACTION = 50.0;
	f128 a = +2.672006e+00; a += std::uniform_real_distribution<f64>(-std::abs((f64)a) / FRACTION, 0)(mt);
	f128 b = +3.438038e+00; b += std::uniform_real_distribution<f64>(-std::abs((f64)b) / FRACTION, 0)(mt);
	#endif
	std::array<f64, 20> vec_c;
	#if !defined(THE_SAME_OLD_FOOL)
	for (usize i = 0; i < 20; ++i) {
		vec_c[i] = CALCULATE_REVENUE_OF(c[i]);
	}
	#else
	vec_c[ 1 - 1] = +3.531998e+00; vec_c[ 1 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[ 1 - 1]) / FRACTION, 0)(mt);
	vec_c[ 2 - 1] = +3.762907e+00; vec_c[ 2 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[ 2 - 1]) / FRACTION, 0)(mt);
	vec_c[ 3 - 1] = +3.730674e+00; vec_c[ 3 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[ 3 - 1]) / FRACTION, 0)(mt);
	vec_c[ 4 - 1] = +3.572335e+00; vec_c[ 4 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[ 4 - 1]) / FRACTION, 0)(mt);
	vec_c[ 5 - 1] = +3.349178e+00; vec_c[ 5 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[ 5 - 1]) / FRACTION, 0)(mt);
	vec_c[ 6 - 1] = +3.091427e+00; vec_c[ 6 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[ 6 - 1]) / FRACTION, 0)(mt);
	vec_c[ 7 - 1] = +2.814828e+00; vec_c[ 7 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[ 7 - 1]) / FRACTION, 0)(mt);
	vec_c[ 8 - 1] = +2.527842e+00; vec_c[ 8 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[ 8 - 1]) / FRACTION, 0)(mt);
	vec_c[ 9 - 1] = +2.235097e+00; vec_c[ 9 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[ 9 - 1]) / FRACTION, 0)(mt);
	vec_c[10 - 1] = +1.939146e+00; vec_c[10 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[10 - 1]) / FRACTION, 0)(mt);
	vec_c[11 - 1] = +1.641407e+00; vec_c[11 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[11 - 1]) / FRACTION, 0)(mt);
	vec_c[12 - 1] = +1.342671e+00; vec_c[12 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[12 - 1]) / FRACTION, 0)(mt);
	vec_c[13 - 1] = +1.043377e+00; vec_c[13 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[13 - 1]) / FRACTION, 0)(mt);
	vec_c[14 - 1] = +7.437717e-01; vec_c[14 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[14 - 1]) / FRACTION, 0)(mt);
	vec_c[15 - 1] = +4.439923e-01; vec_c[15 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[15 - 1]) / FRACTION, 0)(mt);
	vec_c[16 - 1] = +1.441156e-01; vec_c[16 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[16 - 1]) / FRACTION, 0)(mt);
	vec_c[17 - 1] = -1.558155e-01; vec_c[17 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[17 - 1]) / FRACTION, 0)(mt);
	vec_c[18 - 1] = -4.557769e-01; vec_c[18 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[18 - 1]) / FRACTION, 0)(mt);
	vec_c[19 - 1] = -7.557554e-01; vec_c[19 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[19 - 1]) / FRACTION, 0)(mt);
	vec_c[20 - 1] = -1.055743e+00; vec_c[20 - 1] += std::uniform_real_distribution<f64>(-std::abs(vec_c[20 - 1]) / FRACTION, 0)(mt);
	#endif
	const f128 c = *std::max_element(vec_c.begin(), vec_c.end());
	const std::vector<std::string> values = { std::to_string(a), std::to_string(b), std::to_string(c), };
	response.widget = new OptionsWidget(literals::response::prompts, values, true);
	response.layout->addWidget(response.widget);
	delete results;

	QVector<double> x;
	QVector<double> y;
	for (usize i = 0; i < 20; ++i) {
		std::cout << "2 x " << (i + 1) << ": " << (f128)vec_c[i] << '\n';
		x.push_back(i + 1);
		y.push_back(vec_c[i]);
	};
	if (plot != nullptr) {
		central.layout->removeWidget(plot);
		delete plot;
	}
	plot = newCustomPlot(x, y);
	central.layout->addWidget(plot, PLOT_STRETCH);
}
