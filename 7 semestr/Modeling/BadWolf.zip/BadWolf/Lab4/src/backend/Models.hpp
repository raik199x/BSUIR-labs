#pragma once

#include <common/backend/IModel.hpp>

template <const usize N>
class UnqueuedModel : public IModel<N, 0> {
	static constexpr const usize Q = 0;
public:
	UnqueuedModel(void) : IModel<N, Q>() {}
	~UnqueuedModel(void) = default;
	void shift(const Actions<N>& actions) override {
		for (usize i = 1u; i < N; ++i) {
			if (actions.at(i) && IModel<N, Q>::devices.at(i).state == Device::State::BUSY) {
				IModel<N, Q>::devices.at(i).state = Device::State::FREE;
				++IModel<N, Q>::handled;
			}
		}
		if (IModel<N, Q>::devices.at(0).state == Device::State::BUSY) {
			bool passed = false;
			if (actions.at(0)) {
				for (usize i = 1u; i < N; ++i) {
					if (IModel<N, Q>::devices.at(i).state == Device::State::FREE) {
						IModel<N, Q>::devices.at(i).state = Device::State::BUSY;
						IModel<N, Q>::devices.at(0).state = Device::State::FREE;
						passed = true;
						break;
					}
				}
			}
			if (!passed) {
				switch (IModel<N, Q>::devices.at(0).policy) {
				case Device::Policy::DISCARD:
					IModel<N, Q>::devices.at(0).state = Device::State::FREE;
					break;
				case Device::Policy::SUSPEND:
					break;
				default:
					throw std::runtime_error("Unknown policy");
				}
			}
		}
	}
};

template <const usize Q>
class QueuedModel : public IModel<3, Q> {
	static constexpr const usize N = 3;
public:
	QueuedModel(void) : IModel<N, Q>() {}
	virtual ~QueuedModel(void) = default;
public:
	void shift(const Actions<N>& actions) override {
		for (usize i = 1u; i < N; ++i) {
			if (actions.at(i) && IModel<N, Q>::devices.at(i).state == Device::State::BUSY) {
				IModel<N, Q>::devices.at(i).state = Device::State::FREE;
				++IModel<N, Q>::handled;
			}
		}
		for (usize i = 1u; i < N; ++i) {
			if (IModel<N, Q>::queue.empty()) { break; }
			if (IModel<N, Q>::devices.at(i).state == Device::State::FREE) {
				IModel<N, Q>::devices.at(i).state = Device::State::BUSY;
				IModel<N, Q>::queue.pop();
			}
		}
		if (IModel<N, Q>::devices.at(0).state == Device::State::BUSY) {
			if (IModel<N, Q>::queue.free()) {
				IModel<N, Q>::queue.push();
				IModel<N, Q>::devices.at(0).state = Device::State::FREE;
			} else {
				switch(IModel<N, Q>::devices.at(0).policy) {
				case Device::Policy::DISCARD:
					IModel<N, Q>::devices.at(0).state = Device::State::FREE;
					break;
				case Device::Policy::SUSPEND:
					break;
				default:
					throw std::runtime_error("Unknown policy");
				}
			}
		}
	}
};
