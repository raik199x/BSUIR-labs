#pragma once

#include <common/core/types.hpp>

namespace statistics {
	template <typename T>
	f128 mean(const T* const values, const usize size) {
		f128 sum = 0;
		for (usize i = 0; i < size; ++i) {
			sum += static_cast<f128>(values[i]);
		}
		return sum / static_cast<f128>(size);
	}
	template <typename T>
	f128 variance(const T* const values, const usize size, const f128 mean) {
		f128 variance = 0;
		for (usize i = 0; i < size; ++i) {
			const f128 tmp = static_cast<f128>(values[i]) - mean;
			variance += tmp * tmp;
		}
		return variance / static_cast<f128>(size);
	}
	template <typename T>
	T min(const T* const values, const usize size) {
		usize min_index = 0;
		for (usize i = 1; i < size; ++i) {
			if (values[i] < values[min_index]) {
				min_index = i;
			}
		}
		return values[min_index];
	}
	template <typename T>
	T max(const T* const values, const usize size) {
		usize max_index = 0;
		for (usize i = 1; i < size; ++i) {
			if (values[i] > values[max_index]) {
				max_index = i;
			}
		}
		return values[max_index];
	}
}
