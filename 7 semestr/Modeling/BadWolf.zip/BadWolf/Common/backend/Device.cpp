#include <common/core/types.hpp>
#include <common/backend/Device.hpp>

std::ostream& operator<<(std::ostream& os, const Device& device) {
	const auto state = device.state;
	switch (state) {
	case Device::State::FREE:
		[[fallthrough]];
	case Device::State::BUSY:
		os << static_cast<usize>(state);
		break;
	default:
		throw std::logic_error("Invalid Device::State");
	};
	return os;
}
