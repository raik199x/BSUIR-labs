#pragma once

#include <common/core/types.hpp>

template <const usize Q>
class Queue {
public:
	Queue(const usize counter = 0u) : counter(counter) {
		if (counter > Q)
			throw std::runtime_error("Failed to create queue");
	}
	~Queue(void) = default;
public:
	friend std::ostream& operator<<(std::ostream& os, const Queue& model) {
		os << model.counter;
		return os;
	}
public:
	void push(void) {
		if (counter + 1 > Q)
			throw std::runtime_error("Failed to push queue");
		++counter;
	}
	void pop(void) {
		if (counter == 0)
			throw std::runtime_error("Failed to pop queue");
		--counter;
	}
	bool free(void) const {
		return counter + 1 <= Q;
	}
	bool empty(void) const {
		return counter == 0;
	}
private:
	usize counter;
};
