#pragma once

#include <ostream>

#include <common/core/types.hpp>
#include <common/backend/Device.hpp>
#include <common/backend/Queue.hpp>
#include <common/backend/Actions.hpp>

template<const usize N, const usize Q>
class IModel {
public:
	IModel(void) = default;
	virtual ~IModel(void) = default;
public:
	const Devices<N>& get_devices(void) const {
		return devices;
	}
	void set_devices(const Devices<N>& devices) {
		this->devices = devices;
	}
	const Queue<Q>& get_queue(void) const {
		return queue;
	}
	void set_queue(const Queue<Q>& queue) {
		this->queue = queue;
	}
public:
	virtual void shift(const Actions<N>& actions) = 0;
public:
	friend std::ostream& operator<<(std::ostream& os, const IModel<N, Q>& model) {
		if (Q != 0) {
			os << model.queue << ' ';
		}
		if (N != 0) {
			for (const auto& device : model.devices) {
				os << device;
			}
		}
		return os;
	}
protected:
	Devices<N> devices = {};
	Queue<Q> queue = {};
public:
	usize handled = 0;
};
