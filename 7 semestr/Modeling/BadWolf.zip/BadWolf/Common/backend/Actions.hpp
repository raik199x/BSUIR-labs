#pragma once

#include <array>
#include <ranges>
#include <ostream>

#include <common/core/types.hpp>

template <const usize N>
using Actions = std::array<bool, N>;

template <const usize N>
std::ostream& operator<<(std::ostream& os, const Actions<N> actions) {
	for (const auto& action : actions) {
		os << action;
	}
	return os;
}

template <const usize N>
Actions<N> to_actions(usize value) {
	if (value >= (1 << N))
		throw std::runtime_error("Invalid action value");
	Actions<N> actions;
	for (auto& action : std::ranges::views::reverse(actions)) {
		action = (value & 1) == 1;
		value >>= 1;
	}
	return actions;
}

template <const usize N>
usize from_actions(const Actions<N>& actions) {
	usize value = 0;
	for (const auto& action : actions) {
		value <<= 1;
		value |= (action ? 1 : 0);
	}
	return value;
}
