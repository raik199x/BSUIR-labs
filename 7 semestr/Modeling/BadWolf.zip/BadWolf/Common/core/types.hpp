#pragma once

#include <stdfloat>
#include <cstdint>
#include <type_traits>

using u8 = std::uint8_t;
using u16 = std::uint16_t;
using u32 = std::uint32_t;
using u64 = std::uint64_t;
using usize = std::size_t;

using i8 = std::int8_t;
using i16 = std::int16_t;
using i32 = std::int32_t;
using i64 = std::int64_t;
using isize = std::make_signed_t<std::size_t>;

#if defined(__SIZEOF_INT128__)
	using u128 = unsigned __int128;
	using i128 = signed __int128;
#else
	#warning "128-bit integer could not be defined"
#endif

#if __STDCPP_FLOAT16_T__
	using f16 = std::float16_t;
#else
	#error "16-bit float type required"
#endif
#if __STDCPP_FLOAT32_T__
	using f32 = std::float32_t;
#else
	#error "32-bit float type required"
#endif
#if __STDCPP_FLOAT64_T__
	using f64 = std::float64_t;
#else
	#error "64-bit float type required"
#endif
#if __STDCPP_FLOAT128_T__
	using f128 = std::float128_t;
#else
	#error "128-bit float type required"
#endif
