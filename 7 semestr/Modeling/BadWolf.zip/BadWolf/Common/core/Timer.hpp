#pragma once

#include <chrono>

#include <common/core/types.hpp>

class Timer {
public:
	Timer(void) = default;
	~Timer(void) = default;
	void start(void);
	void stop(void);
	usize hours(void);
	usize minutes(void);
	usize seconds(void);
	usize milliseconds(void);
	usize microseconds(void);
	usize nanoseconds(void);
private:
	bool m_running = false;
	std::chrono::high_resolution_clock::time_point m_start, m_stop;
};
