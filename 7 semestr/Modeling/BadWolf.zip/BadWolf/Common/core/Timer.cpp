#include <common/core/Timer.hpp>

using std::chrono::high_resolution_clock, std::chrono::duration_cast;

void Timer::start(void) {
	if (m_running) throw std::logic_error("Timer is already running");
	m_start = high_resolution_clock::now();
	m_running = true;
}
void Timer::stop(void) {
	if (!m_running) throw std::logic_error("Timer is not running");
	m_stop = high_resolution_clock::now();
	m_running = false;
}

usize Timer::hours(void) {
	return duration_cast<std::chrono::hours>(m_stop - m_start).count();
}
usize Timer::minutes(void) {
	return duration_cast<std::chrono::minutes>(m_stop - m_start).count() % 60;
}
usize Timer::seconds(void) {
	return duration_cast<std::chrono::seconds>(m_stop - m_start).count() % 60;
}
usize Timer::milliseconds(void) {
	return duration_cast<std::chrono::milliseconds>(m_stop - m_start).count() % 1000;
}
usize Timer::microseconds(void) {
	return duration_cast<std::chrono::microseconds>(m_stop - m_start).count() % 1000;
}
usize Timer::nanoseconds(void) {
	return duration_cast<std::chrono::nanoseconds>(m_stop - m_start).count() % 1000;
}
