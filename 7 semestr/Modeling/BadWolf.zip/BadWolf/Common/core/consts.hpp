#pragma once

static constexpr const char endl = '\n';
