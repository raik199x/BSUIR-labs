#pragma once

#include <vector>

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>

class OptionsWidget : public QWidget {
	Q_OBJECT
public:
	OptionsWidget(
		const std::vector<std::string>& prompts,
		const std::vector<std::string>& values,
		const bool active,
		QWidget* const parent = nullptr
	);
	~OptionsWidget(void);
private:
	// Central components
	struct {
		QVBoxLayout* layout = nullptr;
	} central;
	// Options
	typedef struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QLineEdit* line = nullptr;
	} OptionType;
	std::vector<OptionType> options;
public:
	QStringView option(const std::string& prompt) const;
};
