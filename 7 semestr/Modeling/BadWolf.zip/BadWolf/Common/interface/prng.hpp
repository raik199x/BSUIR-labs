#pragma once

#include <string>
#include <vector>
#include <cstdint>

#include <common/math/prng.hpp>
#include <common/interface/OptionsWidget.hpp>

#define literal static constexpr

namespace literals::constants {
	literal auto PRNG_GENERATORS = 6ul;
	literal auto PRNG_DISTRIBUTIONS = 9ul;
}

namespace literals::request {
	literal auto dropdown = "Dropdown";

	literal const char* const generators[literals::constants::PRNG_GENERATORS] = {
		"Lehmer",
		"Tausworthe (Feedback Shift Register)",
		"Middle Product",
		"Linear Congruential",
		"Middle Square",
		"Uniform Discrete Distribution (C++ Standard)",
	};
	static const std::vector<std::string> generator_options[literals::constants::PRNG_GENERATORS] = {
		{ "a (multiplier)", "m (modulus)", "seed", },
		{ "depth", "seed", },
		{ "R0 (seed0)", "R1 (seed1)", },
		{ "multiplier", "increment", "modulus)", "seed", },
		{ "seed", },
		{ },
	};
	static const std::vector<std::string> generator_values[literals::constants::PRNG_GENERATORS] = {
		{ "18446744073709551031", "18446744073709551577", "18446744073709550719", },
		{ "4096", "1844674407", },
		{ "18446744073709551031", "18446744073709550719", },
		{ "18446744073709551031", "18446744073709551031", "18446744073709551577", "18446744073709550719", },
		{ "9999999999999999999", },
		{ },
	};
	literal const char* const distributions[literals::constants::PRNG_DISTRIBUTIONS] = {
		"Uniform",
		"Normal-Gaussian (Box-Muller transform)",
		"Exponential",
		"Gamma (ln[∏])",
		"Triangular",
		"Simpson's",
		"Gamma (Σ[ln])",
		"Normal-Gaussian (Σ[R] method)",
		"Geometric",
	};
	static const std::vector<std::string> distribution_options[literals::constants::PRNG_DISTRIBUTIONS] = {
		{ "a (min)", "b (max)", },
		{ "m (mean)", "σ (standard deviation)", },
		{ "λ (rate)", },
		{ "η (shape)", "λ (rate)", },
		{ "a (min)", "b (max)", "c (mode)", },
		{ "a (min)", "b (max)", },
		{ "η (shape)", "λ (rate)", },
		{ "m (mean)", "σ (standard deviation)", "n (N in [6, 12])", },
		{ "p (success probability)", },
	};
	static const std::vector<std::string> distribution_values[literals::constants::PRNG_DISTRIBUTIONS] = {
		{ "0", "50000", },
		{ "500", "35", },
		{ "0.00000000001", },
		{ "1", "0.00000000001", },
		{ "0", "50000", "0", },
		{ "0", "50000", },
		{ "1", "0.00000000001", },
		{ "500", "35", "6", },
		{ "0.5", }
	};
}

#undef literal

namespace request {
	prng::IGenerator<u64>* generator(const OptionsWidget* const widget, const usize request);
	prng::IDistribution<u64>* distribution(const OptionsWidget* const widget, const usize request);
}
