#include <QtCore>

#include <common/interface/ZoomImageLabel.hpp>

ZoomImageLabel::ZoomImageLabel(QWidget* parent) : QLabel(parent) {
	setScaledContents(true);
}

void ZoomImageLabel::wheelEvent(QWheelEvent* event) {
	if (event->modifiers() == Qt::ControlModifier) {
		int delta = event->angleDelta().y();
		double scaleFactor = qPow(1.0015, delta);
		// Apply zoom scale factor
		QSize newSize = size() * scaleFactor;
		setFixedSize(newSize);
		event->accept();
	} else {
		QLabel::wheelEvent(event);
	}
}
