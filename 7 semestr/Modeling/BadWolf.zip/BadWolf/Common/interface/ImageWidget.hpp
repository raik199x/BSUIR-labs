#pragma once

#include <QWidget>
#include <QVBoxLayout>
#include <QScrollArea>
#include <QLabel>

#include <common/interface/ZoomImageLabel.hpp>

class ImageWidget : public QWidget {
	Q_OBJECT
public:
	ImageWidget(QWidget *parent = nullptr);
	~ImageWidget(void);
public:
	void clear(void);
	void open(const QString& title, const QString& path);
private:
	// Central components
	struct {
		QVBoxLayout* layout = nullptr;
		QScrollArea* scroll = nullptr;
	} central;
	// Image
	struct {
		QLabel* title = nullptr;
		ZoomImageLabel* label = nullptr;
	} image;
};
