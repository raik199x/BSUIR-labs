#include <iostream>

#include <common/core/types.hpp>
#include <common/interface/OptionsWidget.hpp>

static const QString SEPARATOR = QString("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");

OptionsWidget::OptionsWidget(
	const std::vector<std::string>& prompts,
	const std::vector<std::string>& values,
	const bool active,
	QWidget* const parent
) : QWidget(parent) {
	// Validation
	const usize N = prompts.size();
	if (N != values.size())
		throw std::invalid_argument("OptionsWidget: prompts.size() != values.size()");
	for (usize i = 0; i < N; ++i) {
		for (usize j = 0; j < N; ++j) {
			if (i == j) continue;
			if (prompts[i] == prompts[j])
				throw std::invalid_argument("OptionsWidget: prompts are not unique");
		}
	}
	// Layout
	central.layout = new QVBoxLayout;
	// Options
	options.resize(N);
	for (usize i = 0; i < N; ++i) {
		options[i].layout = new QHBoxLayout;
		options[i].prompt = new QLabel(SEPARATOR + prompts[i].c_str());
		options[i].prompt->setTextFormat(Qt::RichText);
		options[i].layout->addWidget(options[i].prompt, 1);
		options[i].line = new QLineEdit;
		options[i].line->setText(values[i].c_str());
		options[i].line->setEnabled(active);
		options[i].layout->addWidget(options[i].line, 1);
		central.layout->addLayout(options[i].layout);
	}
	// Central components
	setLayout(central.layout);
}

OptionsWidget::~OptionsWidget(void) {
	// Options
	for (usize i = 0; i < options.size(); ++i) {
		options[i].layout->removeWidget(options[i].line);
		delete options[i].line;
		options[i].layout->removeWidget(options[i].prompt);
		delete options[i].prompt;
		central.layout->removeItem(options[i].layout);
		delete options[i].layout;
	}
	// Central components
	delete central.layout;
}

QStringView OptionsWidget::option(const std::string& prompt) const {
	// Find option with prompt and return it
	for (const auto& option : options) {
		if (option.prompt->text() != (SEPARATOR + prompt.c_str())) { continue; }
		std::clog << "[ LOG ] OptionsWidget: the `" << prompt << "' option was found" << std::endl;
		return option.line->text();
	}
	throw std::runtime_error("OptionsWidget: the `" + prompt + "' option was not found");
}
