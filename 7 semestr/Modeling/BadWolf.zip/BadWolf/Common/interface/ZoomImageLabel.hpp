#pragma once

#include <QLabel>
#include <QWidget>
#include <QWheelEvent>

class ZoomImageLabel : public QLabel {
public:
	explicit ZoomImageLabel(QWidget* parent = nullptr);
protected:
	void wheelEvent(QWheelEvent* event) override;
};
