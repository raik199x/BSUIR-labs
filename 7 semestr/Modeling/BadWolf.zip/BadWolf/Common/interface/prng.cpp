#include <common/interface/prng.hpp>

prng::IGenerator<u64>* request::generator(const OptionsWidget* const widget, const usize request) {
	#define find_option(n) widget->option(literals::request::generator_options[request].at(n))
	switch (request) {
	case 0: {
		const auto multiplier = find_option(0);
		const auto modulus    = find_option(1);
		const auto seed       = find_option(2);
		return new prng::Lehmer<u64>(
			multiplier.toULongLong(),
			modulus.toULongLong(),
			seed.toULongLong()
		);
	}
	case 1: {
		const auto depth = find_option(0);
		const auto seed  = find_option(1);
		return new prng::Tausworthe<u64>(
			depth.toULongLong(),
			seed.toULong()
		);
	}
	case 2: {
		const auto seed0 = find_option(0);
		const auto seed1 = find_option(1);
		return new prng::MiddleProduct<u64, u128>(
			seed0.toULongLong(),
			seed1.toULongLong()
		);
	}
	case 3: {
		const auto multiplier = find_option(0);
		const auto increment  = find_option(1);
		const auto modulus    = find_option(2);
		const auto seed       = find_option(3);
		return new prng::LinearCongruential<u64>(
			multiplier.toULongLong(),
			increment.toULongLong(),
			modulus.toULongLong(),
			seed.toULongLong()
		);
	}
	case 4: {
		const auto seed = find_option(0);
		return new prng::MiddleSquare<u64, u128>(
			seed.toULongLong()
		);
	}
	case 5: {
		return new prng::Standard<u64>();
	}
	default:
		throw std::runtime_error("Invalid generator");
	}
	#undef find_option
}

prng::IDistribution<u64>* request::distribution(const OptionsWidget* const widget, const usize request) {
	#define find_option(n) widget->option(literals::request::distribution_options[request].at(n))
	switch (request) {
	case 0: {
		const auto min = find_option(0);
		const auto max = find_option(1);
		return new prng::Uniform<u64>(
			min.toULongLong(),
			max.toULongLong()
		);
	}
	case 1: {
		const auto mean    = find_option(0);
		const auto std_dev = find_option(1);
		return new prng::Normal<u64, prng::NormalImplementation::BOX_MULLER>(
			mean.toULongLong(),
			std_dev.toULongLong()
		);
	}
	case 2: {
		const auto lambda = find_option(0);
		return new prng::Exponential<u64>(
			lambda.toDouble()
		);
	}
	case 3: {
		const auto shape = find_option(0);
		const auto rate  = find_option(1);
		return new prng::Gamma<u64, prng::GammaImplementation::PRODUCT>(
			shape.toULongLong(),
			rate.toDouble()
		);
	}
	case 4: {
		const auto min = find_option(0);
		const auto max = find_option(1);
		const auto mode = find_option(2);
		return new prng::Triangular<u64>(
			min.toULongLong(),
			max.toULongLong(),
			mode.toDouble()
		);
	}
	case 5: {
		const auto min = find_option(0);
		const auto max = find_option(1);
		return new prng::Triangular<u64>(
			min.toULongLong(),
			max.toULongLong()
		);
	}
	case 6: {
		const auto shape = find_option(0);
		const auto rate  = find_option(1);
		return new prng::Gamma<u64, prng::GammaImplementation::SUM>(
			shape.toULongLong(),
			rate.toDouble()
		);
	}
	case 7: {
		const auto mean    = find_option(0);
		const auto std_dev = find_option(1);
		const auto n       = find_option(2);
		return new prng::Normal<u64, prng::NormalImplementation::SUM_R>(
			mean.toULongLong(),
			std_dev.toULongLong(),
			n.toULongLong(),
			request
		);
	}
	case 8: {
		const auto success_probability = find_option(0);
		return new prng::Geometric<u64>(
			success_probability.toDouble()
		);
	}
	default:
		throw std::runtime_error("Invalid distribution");
	}
	#undef find_option
}
