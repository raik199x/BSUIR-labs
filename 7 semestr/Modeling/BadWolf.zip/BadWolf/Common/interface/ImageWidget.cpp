#include <QPixmap>

#include <common/interface/ImageWidget.hpp>

ImageWidget::ImageWidget(QWidget *parent) : QWidget(parent) {
	// Layout
	central.layout = new QVBoxLayout;
	central.scroll = new QScrollArea;
	// Central components
	setLayout(central.layout);
}

ImageWidget::~ImageWidget(void) {
	clear();
	delete central.scroll;
	delete central.layout;
}

void ImageWidget::clear(void) {
	if (image.label != nullptr) {
		central.layout->removeWidget(image.label);
		delete image.label;
	}
	if (image.title != nullptr) {
		central.layout->removeWidget(central.scroll);
		delete image.title;
	}
}

void ImageWidget::open(const QString& title, const QString& path) {
	clear();
	if (!title.isEmpty()) {
		image.title = new QLabel("<b>" + title + "</b>");
		image.title->setAlignment(Qt::AlignCenter);
		central.layout->addWidget(image.title);
	}
	if (!path.isEmpty()) {
		image.label = new ZoomImageLabel;
		const auto pixmap = QPixmap(path);
		image.label->setPixmap(pixmap);
		image.label->setScaledContents(true);
		image.label->setFixedSize(pixmap.size());
		central.scroll->setWidget(image.label);
		central.layout->addWidget(central.scroll);
	}
}
