#pragma once

#include <stdexcept>

#include <common/math/core/bits.hpp>
#include <common/math/core/IGenerator.hpp>

namespace prng {
	/// @brief References: prng::LinearCongruential, prng::MiddleSquare.
	template <typename T, typename X> requires prng::bits::twice<T, X>
	class MiddleProduct : public IGenerator<T> {
	public:
		MiddleProduct(
			const T& seed0 = prng::seed<T>,
			const T& seed1 = prng::seed<T>
		) : seed0(seed0), seed1(seed1) {
			if (seed0 == 0) throw std::invalid_argument("seed0 must be a non-zero value");
			if (seed1 == 0) throw std::invalid_argument("seed1 must be a non-zero value");
		}
		~MiddleProduct(void) = default;
		T next(void) override {
			const X product = static_cast<X>(seed0) * static_cast<X>(seed1);
			const X middle = prng::bits::middle<X>(product);
			return seed0 = seed1, seed1 = static_cast<T>(middle);
		}
	private:
		T seed0, seed1;
	};
}
