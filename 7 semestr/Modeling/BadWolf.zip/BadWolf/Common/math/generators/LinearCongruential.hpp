#pragma once

#include <stdexcept>

#include <common/math/core/IGenerator.hpp>

namespace prng {
	/// @brief References: [Linear congruential generator](https://en.wikipedia.org/wiki/Linear_congruential_generator).
	template <typename T>
	class LinearCongruential : public IGenerator<T> {
	public:
		LinearCongruential(
			const T& multiplier,
			const T& increment,
			const T& modulus,
			const T& seed = prng::seed<T>
		) : multiplier(multiplier), increment(increment), modulus(modulus), seed(seed) {
			if (multiplier == 0) throw std::invalid_argument("multiplier must be a non-zero value");
			if (modulus == 0) throw std::invalid_argument("modulus must be a non-zero value");
			if (seed == 0) throw std::invalid_argument("seed must be a non-zero value");
		}
		~LinearCongruential(void) = default;
		T next(void) override {
			return seed = (multiplier * seed + increment) % modulus;
		}
	protected:
		T multiplier, increment, modulus, seed;
	};
}
