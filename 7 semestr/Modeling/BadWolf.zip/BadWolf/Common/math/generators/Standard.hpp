#pragma once

#include <random>

#include <common/math/core/IGenerator.hpp>

namespace prng {
	/// @brief References: [std::uniform_int_distribution](https://en.cppreference.com/w/cpp/numeric/random/uniform_int_distribution).
	template <typename T> requires std::is_integral_v<T>
	class Standard : public IGenerator<T> {
	public:
		Standard(void) : device(), mt(device()), distribution(std::numeric_limits<T>::min(), std::numeric_limits<T>::max()) {}
		~Standard(void) = default;
		T next(void) override {
			return distribution(mt);
		}
	protected:
		std::random_device device;
		std::mt19937_64 mt;
		std::uniform_int_distribution<T> distribution;
	};
}
