#pragma once

#include <common/math/generators/LinearCongruential.hpp>

namespace prng {
	/// @brief References: [Lehmer random number generator](https://en.wikipedia.org/wiki/Lehmer_random_number_generator).
	template <typename T>
	class Lehmer : public LinearCongruential<T> {
	public:
		Lehmer(
			const T& multiplier,
			const T& modulus,
			const T& seed = prng::seed<T>
		) : LinearCongruential<T>(multiplier, static_cast<T>(0), modulus, seed) {}
		~Lehmer(void) = default;
	};
}
