#pragma once

#include <numeric>
#include <stdexcept>

#include <common/math/core/IGenerator.hpp>

#include <libs/linux/Tausworthe32.hpp>

namespace prng {
	/// @brief References: prng::LinearCongruential, Tausworthe32.
	template <typename T>
	class Tausworthe : public IGenerator<T> {
	public:
		Tausworthe(
			const usize depth,
			const u32 seed = prng::seed<T>
		) : tausworthe(seed, depth) {}
		~Tausworthe(void) = default;
		T next(void) override {
			f128 value = tausworthe.next();
			value /= std::numeric_limits<u32>::max();
			return value * std::numeric_limits<T>::max();
		}
	protected:
		Tausworthe32 tausworthe;
	};
}
