#pragma once

#include <common/math/core/bits.hpp>
#include <common/math/core/IGenerator.hpp>

namespace prng {
	/// @brief References: [Middle square method](https://en.wikipedia.org/wiki/Middle-square_method).
	template <typename T, typename X> requires prng::bits::twice<T, X>
	class MiddleSquare : public IGenerator<T> {
	public:
		MiddleSquare(
			const T& seed = prng::seed<T>
		) : IGenerator<T>(), seed(seed) {
			if (seed == 0) throw std::invalid_argument("seed must be a non-zero value");
		}
		~MiddleSquare(void) = default;
		T next(void) override {
			const X square = static_cast<X>(seed) * static_cast<X>(seed);
			const X middle = prng::bits::middle<X>(square);
			return seed = static_cast<T>(middle);
		}
	private:
		T seed;
	};
}
