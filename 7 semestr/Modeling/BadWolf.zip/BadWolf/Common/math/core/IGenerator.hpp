#pragma once

#include <chrono>

namespace prng {
	template <typename T>
	static constexpr T seed = static_cast<T>(std::time(nullptr));

	/// @brief References: [Wikipedia](https://en.wikipedia.org/wiki/List_of_random_number_generators).
	template <typename T>
	class IGenerator {
	public:
		IGenerator(void) = default;
		virtual ~IGenerator(void) = default;
		virtual T next(void) = 0;
	};
}
