#pragma once

#include <cstdint>

#include <common/core/types.hpp>

namespace prng::bits {
	template <typename T>
	static constexpr usize bitsize = sizeof(T) * 8;

	template <typename T, typename X>
	static constexpr bool twice = bitsize<X> == 2 * bitsize<T>;

	template <typename T>
	usize meaningful(const T& value) {
		usize counter = 0;
		for (usize i = 0; i < bitsize<T>; ++i) {
			if ((value >> (bitsize<T> - i - 1)) & 0b1) break;
			++counter;
		}
		return bitsize<T> - counter;
	}

	template <typename T>
	T middle(const T& value) {
		T result = value;
		const usize meaningful_bits = meaningful<T>(value);
		const usize half = meaningful_bits / 2;
		const usize quarter = half / 2;
		result <<= quarter;
		result >>= half;
		return result;
	}
}
