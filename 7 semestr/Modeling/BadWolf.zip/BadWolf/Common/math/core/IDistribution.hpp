#pragma once

#include <numeric>

#include <common/core/types.hpp>
#include <common/math/core/IGenerator.hpp>

namespace prng {
	template <typename T>
	class IDistribution {
	public:
		IDistribution(void) = default;
		virtual ~IDistribution(void) = default;
		static f128 R(IGenerator<T>* const generator) {
			return static_cast<f128>(generator->next()) / static_cast<f128>(std::numeric_limits<T>::max());
		}
		virtual f128 mean(void) const = 0;
		virtual f128 variance(void) const = 0;
		virtual T next(IGenerator<T>* const generator) = 0;
	};
}
