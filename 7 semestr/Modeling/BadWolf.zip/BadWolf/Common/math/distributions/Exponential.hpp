#pragma once

#include <cmath>

#include <common/core/types.hpp>
#include <common/math/core/IDistribution.hpp>

namespace prng {
	/// @brief References: [Exponential distribution](https://en.wikipedia.org/wiki/Exponential_distribution).
	template <typename T>
	class Exponential : public IDistribution<T> {
		static constexpr const f128 ONE = 1;
		static constexpr const f128 MINUS_ONE = -1;
	public:
		Exponential(const f128 rate_parameter) : rate_parameter(rate_parameter) {
			if (rate_parameter == 0) throw std::invalid_argument("rate_parameter must be a non-zero value");
		}
		~Exponential(void) = default;
		f128 mean(void) const override {
			return ONE / rate_parameter;
		}
		f128 variance(void) const override {
			return ONE / (rate_parameter * rate_parameter);
		}
		T next(IGenerator<T>* const generator) override {
			return MINUS_ONE * std::log(IDistribution<T>::R(generator)) / rate_parameter;
		}
	private:
		f128 rate_parameter;
	};
}
