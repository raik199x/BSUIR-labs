#pragma once

#include <cmath>
#include <vector>

#include <common/core/types.hpp>
#include <common/math/core/IDistribution.hpp>

namespace prng {
	/// @brief Possible implementations
	enum class NormalImplementation {
		BOX_MULLER,
		SUM_R,
	};

	/**
	 * @brief References: [Normal distribution](https://en.wikipedia.org/wiki/Normal_distribution),
	 * [Box-Muller transform](https://en.wikipedia.org/wiki/Box%E2%80%93Muller_transform).
	 */
	template <typename T, const NormalImplementation version>
	class Normal : public IDistribution<T> {
		static constexpr const f128 TWELVE = 12;
		static constexpr const f128 MINUS_TWO = -2;
		static constexpr const f128 TAU = M_PI * 2;
	public:
		f128 mean(void) const override {
			return mean_v;
		}
		f128 variance(void) const override {
			return standard_deviation * standard_deviation;
		}
		Normal(
			const T& mean,
			const T& standard_deviation,
			const usize quantity,
			const usize sequence
		) requires (version == NormalImplementation::SUM_R) : mean_v(mean), standard_deviation(standard_deviation), quantity(quantity), N(quantity), sequence(sequence) {
			if (standard_deviation > mean_v) throw std::invalid_argument("standard_deviation must not be greater than mean");
			if (N < 6) throw std::invalid_argument("quantity must be greater than 6");
		}
		Normal(
			const T& mean,
			const T& standard_deviation
		) requires (version == NormalImplementation::BOX_MULLER) : mean_v(mean), standard_deviation(standard_deviation) {
			if (standard_deviation > mean_v) throw std::invalid_argument("standard_deviation must not be greater than mean");
		}
		~Normal(void) = default;
		T next(IGenerator<T>* const generator) override {
			f128 z;
			switch (version) {
			case NormalImplementation::BOX_MULLER:
				z = nextBoxMuller(generator);
				break;
			case NormalImplementation::SUM_R:
				z = nextSumR(generator);
				break;
			default:
				throw std::invalid_argument("Requested implementation is unknown");
			};
			return mean_v + standard_deviation * z;
		}
	private:
		f128 mean_v, standard_deviation, quantity = 0;
		usize N = 0, sequence = 0;
	protected:
		std::vector<f128> rs;
		f128 nextSumR(IGenerator<T>* const generator) {
			if (rs.empty()) {
				rs.resize(N);
				for (auto& r : rs) {
					r = IDistribution<T>::R(generator);
				}
			}
			f128 sum = std::accumulate(rs.begin(), rs.end(), 0.0);
			for (usize i = 0; i + 1 < N; ++i) {
				rs[i] = rs[i + 1];
			}
			rs.back() = IDistribution<T>::R(generator);
			return std::sqrt(TWELVE / quantity) * (sum - quantity / 2);
		}
		f128 nextBoxMuller(IGenerator<T>* const generator) {
			const auto U1 = IDistribution<T>::R(generator);
			const auto U2 = IDistribution<T>::R(generator);
			return std::sqrt(MINUS_TWO * std::log(U1)) * std::cos(TAU * U2); // z0
			// return std::sqrt(MINUS_TWO * std::log(U1)) * std::sin(TAU * U2); // z1
		}
	};
}
