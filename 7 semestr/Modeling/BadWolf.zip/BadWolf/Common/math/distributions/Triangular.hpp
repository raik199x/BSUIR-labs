#pragma once

#include <cmath>
#include <stdexcept>

#include <common/core/types.hpp>
#include <common/math/core/IDistribution.hpp>

#define a min
#define b max
#define c mode
namespace prng {
	/// @brief References: [Triangular distribution](https://en.wikipedia.org/wiki/Triangular_distribution).
	template <typename T>
	class Triangular : public IDistribution<T> {
	public:
		Triangular(const T& min_v, const T& max_v) : Triangular(min_v, max_v, (f128)(min_v + max_v) / 2) {}
		Triangular(const T& min_v, const T& max_v, const f128 mode_v) : min(min_v), max(max_v), mode(mode_v) {
			if (min >= max) throw std::invalid_argument("min must be less than max");
			if (mode < min || mode > max) throw std::invalid_argument("mode must be between min and max");
			FC = (c - a) / (b - a);
			if (FC < 0 || FC > 1) throw std::range_error("FC must be between 0 and 1");
		}
		~Triangular(void) = default;
		f128 mean(void) const override {
			return (a + b + c) / 3;
		}
		f128 variance(void) const override {
			return (a * a + b * b + c * c - a * b - a * c - b * c) / 18;
		}
		T next(IGenerator<T>* const generator) override {
			const f128 U = IDistribution<T>::R(generator);
			if (U < FC) return a + std::sqrt(   U    * (b - a) * (c - a));
			/* else */  return b - std::sqrt((1 - U) * (b - a) * (b - c));
		}
	private:
		f128 min, max, mode, FC;
	};
}
#undef c
#undef b
#undef a
