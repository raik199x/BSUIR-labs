#pragma once

#include <common/core/types.hpp>
#include <common/math/core/IDistribution.hpp>

namespace prng {
	/// @brief References: [Discrete uniform distribution](https://en.wikipedia.org/wiki/Discrete_uniform_distribution).
	template <typename T>
	class Uniform : public IDistribution<T> {
		static constexpr const f128 TWO = 2;
		static constexpr const f128 TWELVE = 12;
	public:
		Uniform(const T& min, const T& max) : min(min), max(max) {
			if (min > max) throw std::invalid_argument("min must not be greater than max");
		}
		~Uniform(void) = default;
		f128 mean(void) const override {
			return (min + max) / TWO;
		}
		f128 variance(void) const override {
			f128 D = max - min;
			return D * D / TWELVE;
		}
		T next(IGenerator<T>* const generator) override {
			return min + (max - min) * IDistribution<T>::R(generator);
		}
	protected:
		f128 min, max;
	};
}
