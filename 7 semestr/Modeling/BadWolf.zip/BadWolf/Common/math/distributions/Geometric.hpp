#pragma once

#include <cmath>

#include <common/core/types.hpp>
#include <common/math/core/IDistribution.hpp>

namespace prng {
	/// @brief References: [Geometric distribution](https://en.wikipedia.org/wiki/Geometric_distribution).
	template <typename T>
	class Geometric : public IDistribution<T> {
		static constexpr const f128 ZERO = 0.0;
		static constexpr const f128 ONE = 1.0;
	public:
		Geometric(const f128 success_probability) : p(success_probability) {
			if ((success_probability <= ZERO) || (success_probability >= ONE)) throw std::invalid_argument("p must be in range (0, 1)");
		}
		~Geometric(void) = default;
		virtual f128 mean(void) const override {
			return (ONE - p) / p;
		}
		virtual f128 variance(void) const override {
			return (ONE - p) / (p * p);
		}
		virtual T next(IGenerator<T>* const generator) {
			return std::log(IDistribution<T>::R(generator)) / std::log(ONE - p);
		}
	private:
		f128 p;
	};
}
