#pragma once

#include <cmath>
#include <stdexcept>

#include <common/core/types.hpp>
#include <common/math/core/IDistribution.hpp>

namespace prng {
	/// @brief Possible implementations
	enum class GammaImplementation {
		PRODUCT,
		SUM,
	};

	/// @brief References: [Gamma distribution](https://en.wikipedia.org/wiki/Gamma_distribution).
	template <typename T, const GammaImplementation version>
	class Gamma : public IDistribution<T> {
		static constexpr const f128 MINUS_ONE = -1;
	public:
		Gamma(const usize shape, const f128 rate) : shape(shape), rate(rate) {
			if (shape == 0) throw std::invalid_argument("shape must be a non-zero value");
			if (rate == 0) throw std::invalid_argument("rate must be a non-zero value");
		}
		~Gamma(void) = default;
		f128 mean(void) const override {
			return shape / rate;
		}
		f128 variance(void) const override {
			return shape / (rate * rate);
		}
		T next(IGenerator<T>* const generator) override {
			switch (version) {
			case GammaImplementation::PRODUCT:
				return nextProduct(generator);
			case GammaImplementation::SUM:
				return nextSum(generator);
			default:
				throw std::invalid_argument("Requested implementation is unknown");
			};
		}
	protected:
		usize shape;
		f128 rate;
	private:
		T nextProduct(IGenerator<T>* const generator) {
			f128 product = 1;
			for (usize i = 0; i < shape; ++i) {
				product *= IDistribution<T>::R(generator);
			}
			return MINUS_ONE / rate * std::log(product);
		}
		T nextSum(IGenerator<T>* const generator) {
			f128 sum = 0;
			for (usize i = 0; i < shape; ++i) {
				sum += std::log(IDistribution<T>::R(generator));
			}
			return MINUS_ONE / rate * sum;
		}
	};
}
