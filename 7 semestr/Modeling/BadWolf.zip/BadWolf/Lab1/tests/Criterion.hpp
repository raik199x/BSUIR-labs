#pragma once

#include <format>
#include <iostream>

#include <criterion/criterion.h>

#include <core/improve.hpp>

using namespace cpp::improved;

#ifndef test_type
#error "test_type must be defined"
#endif

static constexpr test_type test_modulus = static_cast<test_type>(18446744073709551577ull);
static constexpr test_type test_correction = static_cast<test_type>(1111111111123456789ull);
static constexpr test_type test_multiplier = static_cast<test_type>(test_modulus - 1 * test_correction);
static constexpr test_type test_increment = static_cast<test_type>(test_modulus - 2 * test_correction);
static constexpr test_type test_seed = static_cast<test_type>(test_modulus - 3 * test_correction);

static constexpr struct { usize row, column; } test_limit = { 50, 6 };

#define print(...) std::cout << std::format(__VA_ARGS__)
#define println(...) print(__VA_ARGS__) << std::endl
#define eprint(...) std::cerr << std::format(__VA_ARGS__)
#define eprintln(...) eprint(__VA_ARGS__) << std::endl

#define ___concatenate(a, b) a##b
#define concatenate(a, b) ___concatenate(a, b)
#define stringify(a) #a
