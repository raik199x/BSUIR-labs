#include <backend/math/InversiveCongruential.hpp>

#define UNIT .disabled = false

#define test_type u64
#include <tests/Criterion.hpp>

#include <numeric>

test_type find_prime(void) {
	test_type value = std::numeric_limits<test_type>::max();
	while (true) {
		try {
			prng::InversiveCongruential<test_type> prng(test_multiplier, test_increment, value, test_seed);
			return value;
		} catch (...) {
			--value;
		}
	}
	
}

Test(PrimeSeeker, test_type, UNIT) {
	// prng::InversiveCongruential<test_type> prng(test_multiplier, test_increment, test_modulus, test_seed);
	// for (usize row = 0; row < test_limit.row; ++row) {
	// 	for (usize column = 0; column < test_limit.column; ++column)
	// 		print("{:12}", prng.next());
	// 	println("");
	// }
	const test_type prime = find_prime();
	std::cout << "Found prime: " << prime << std::endl;
}
