#include <cmath>

#include <backend/magic.hpp>

/**
 * @brief Testing type
 * @example u8 :: <30sec
 * @example u16 :: <30sec
 * @example u32 :: ~30sec
 * @example u64 :: too long
 */
#define test_type u16
#include <tests/Criterion.hpp>

class Validator {
	public:
		Validator(void) = default;
		~Validator(void) = default;
		usize operator()(void) {
			usize result = _result;
			++_iteration;
			if (_iteration == _limit) {
				_iteration = 0;
				++_result;
				if (_result > 1)
					_limit *= 2;
			}
			return result;
		}
	private:
		usize _result = 0;
		usize _iteration = 0;
		usize _limit = 1;
};

Test(BitMagic, meaningful_bits) {
	Validator check;
	test_type value = 0;
	bool overflow = false;
	while(true) {
		if (value == 0 && overflow) break;
		if (value == 0) overflow = true;
		usize result = bit::magic::meaningful_bits<test_type>(value);
		usize expected = check();
		cr_assert(result == expected, "Expected %lu, got %lu :: value = %lu", expected, result, value);
		++value;
	}
}
