#include <backend/math/LaggedFibonacci.hpp>

#define UNIT .disabled = true

#define test_type u64
#include <tests/Criterion.hpp>

constexpr usize j = 7;
constexpr usize k = 10;

void test_case(const std::function<test_type(test_type, test_type)>& mode) {
	std::vector<test_type> initial = { test_multiplier, test_increment, test_modulus, test_seed, ~test_seed, ~test_modulus, ~test_increment, ~test_multiplier,
									   test_multiplier*test_multiplier, test_increment*test_increment, test_modulus*test_modulus, test_seed*test_seed,
									   ~(test_multiplier*test_multiplier), ~(test_increment*test_increment), ~(test_modulus*test_modulus), ~(test_seed*test_seed) };
	prng::LaggedFibonacci<test_type> prng(mode, initial, j, k, test_modulus);
	for (usize row = 0; row < test_limit.row; ++row) {
		for (usize column = 0; column < test_limit.column; ++column)
			print("{:21}", prng.next());
		println("");
	}
}

Test(LaggedFibonacci, concatenate(test_type, Additive), UNIT) {
	test_case(prng::Additive<test_type>);
}
Test(LaggedFibonacci, concatenate(test_type, Subtractive), UNIT) {
	test_case(prng::Subtractive<test_type>);
}
Test(LaggedFibonacci, concatenate(test_type, Multiplicative), UNIT) {
	test_case(prng::Multiplicative<test_type>);
}
Test(LaggedFibonacci, concatenate(test_type, BitwiseXOR), UNIT) {
	test_case(prng::BitwiseXOR<test_type>);
}
