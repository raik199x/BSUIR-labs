#include <backend/math/Rule30.hpp>

#define UNIT .disabled = false

#define test_type u64
#define test_twice u128
#include <tests/Criterion.hpp>

Test(Rule30, concatenate(test_type, test_type), UNIT) {
	prng::Rule30<test_type, test_type, true> prng(test_seed);
	for (usize row = 0; row < test_limit.row; ++row) {
		for (usize column = 0; column < test_limit.column; ++column)
			print("{:21}", prng.next());
		println("");
	}
}

Test(Rule30, concatenate(test_type, test_twice), UNIT) {
	prng::Rule30<test_type, test_twice> prng(test_seed);
	for (usize row = 0; row < test_limit.row; ++row) {
		for (usize column = 0; column < test_limit.column / 2; ++column)
			print("{:21}", prng.next());
		println("");
	}
}
