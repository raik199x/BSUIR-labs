#include <backend/math/MiddleSquare.hpp>

#define UNIT .disabled = true

#define test_type u64
#define test_twice u128
#include <tests/Criterion.hpp>

Test(MiddleSquare, concatenate(test_type, test_type), UNIT) {
	prng::MiddleSquare<test_type, test_type, true> prng(test_seed);
	for (usize row = 0; row < test_limit.row; ++row) {
		for (usize column = 0; column < test_limit.column; ++column)
			print("{:21}", prng.next());
		println("");
	}
}

Test(MiddleSquare, concatenate(test_type, test_twice), UNIT) {
	prng::MiddleSquare<test_type, test_twice> prng(test_seed);
	for (usize row = 0; row < test_limit.row; ++row) {
		for (usize column = 0; column < test_limit.column / 2; ++column)
			print("{:21}", prng.next());
		println("");
	}
}
