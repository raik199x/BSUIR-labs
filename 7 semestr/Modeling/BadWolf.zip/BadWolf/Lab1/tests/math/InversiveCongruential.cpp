#include <backend/math/InversiveCongruential.hpp>

#define UNIT .disabled = false

#define test_type u64
#include <tests/Criterion.hpp>

Test(InversiveCongruential, test_type, UNIT) {
	prng::InversiveCongruential<test_type> prng(test_multiplier, test_increment, test_modulus, test_seed);
	for (usize row = 0; row < test_limit.row; ++row) {
		for (usize column = 0; column < test_limit.column; ++column)
			print("{:21}", prng.next());
		println("");
	}
}
