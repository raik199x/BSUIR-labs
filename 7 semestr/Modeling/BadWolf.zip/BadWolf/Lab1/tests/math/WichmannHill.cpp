#include <backend/math/WichmannHill.hpp>

#define UNIT .disabled = true

#define test_type f32
#include <tests/Criterion.hpp>

#define lehmer_type u128

Test(WichmannHill, concatenate(test_type, lehmer_type), UNIT) {
	prng::WichmannHill<test_type, lehmer_type> prng(9999, 19999, 29999);
	for (usize row = 0; row < test_limit.row * 100; ++row) {
		for (usize column = 0; column < test_limit.column; ++column)
			print("{:21}", prng.next());
		println("");
	}
}
