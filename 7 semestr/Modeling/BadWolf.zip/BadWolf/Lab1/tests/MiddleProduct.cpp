#include <backend/MiddleProduct.hpp>

#define test_type u64
#define test_twice u128
#include <tests/Criterion.hpp>

Test(MiddleProduct, concatenate(test_type, test_type)) {
	prng::MiddleProduct<test_type, test_type, true> prng(test_seed, ~test_seed);
	for (usize row = 0; row < test_limit.row; ++row) {
		for (usize column = 0; column < test_limit.column; ++column)
			print("{:21}", prng.next());
		println("");
	}
}

Test(MiddleProduct, concatenate(test_type, test_twice)) {
	prng::MiddleProduct<test_type, test_twice> prng(test_seed, ~test_seed);
	for (usize row = 0; row < test_limit.row; ++row) {
		for (usize column = 0; column < test_limit.column / 2; ++column)
			print("{:21}", prng.next());
		println("");
	}
}
