#include <backend/Lehmer.hpp>

#define test_type u64
#include <tests/Criterion.hpp>

Test(Lehmer, test_type) {
	prng::Lehmer<test_type> prng(test_multiplier, test_modulus, test_seed);
	for (usize row = 0; row < test_limit.row; ++row) {
		for (usize column = 0; column < test_limit.column; ++column)
			print("{:21}", prng.next());
		println("");
	}
}
