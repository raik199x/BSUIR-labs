#pragma once

#include <backend/PRNG.hpp>
#include <backend/magic.hpp>
 
namespace prng {
	template <typename T, typename X, bool force = false>
		requires force || bit::magic::twice<T, X>
	class MiddleProduct : public IGenerator<T> {
	public:
		MiddleProduct(const T& seed0 = prng::seed<T>, const T& seed1 = prng::seed<T>) : _seed0(seed0), _seed1(seed1) {}
		~MiddleProduct(void) = default;
		T next(void) override {
			const X product = static_cast<X>(_seed0) * static_cast<X>(_seed1);
			const X middle = bit::magic::middle_bits<X>(product);
			return _seed0 = _seed1, _seed1 = static_cast<T>(middle);
		}
	private:
		T _seed0, _seed1;
	};
}
