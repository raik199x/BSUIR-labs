#pragma once

#include <backend/PRNG.hpp>

#include <backend/magic.hpp>

namespace prng {
	template <typename T, typename X, bool force = false>
		requires force || (bit::magic::bitsize<X> == 2 * bit::magic::bitsize<T>)
	class Rule30 : public IGenerator<T> {
	public:
		Rule30(const T& seed) : _seed(seed) {};
		~Rule30() = default;
		T next() {
			/* todo:
			 * X is twice as long as T
			 * Store _seed in the middle of X tmp_value
			 * Apply Rule 30 to tmp_value bit::magic::bitsize<T> times
			 * Extract the middle of tmp_value and store it in _seed, return _seed
			 */
			const usize half = bit::magic::bitsize<X> / 2;
			X tmp_value = static_cast<X>(_seed) << half;
			for (size_t i = 0; i < half; ++i) {
				tmp_value = applyRule30(tmp_value);
			}
			return _seed = static_cast<T>(tmp_value >> half);
		}
	protected:
		T _seed;
	private:
		X applyRule30(X value) {
			X result = 0;
			for (size_t i = 1; i < bit::magic::bitsize<X> - 1; ++i) {
				bool left = (value >> (i - 1)) & 1;
				bool center = (value >> i) & 1;
				bool right = (value >> (i + 1)) & 1;
				bool new_bit = left ^ (center || right);
				result |= static_cast<X>(new_bit) << i;
			}
			return result;
		}
	};
}
