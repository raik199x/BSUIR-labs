#pragma once

#include <backend/PRNG.hpp>

namespace prng {
	template <typename T>
	class LinearCongruential : public IGenerator<T> {
	public:
		LinearCongruential(const T& multiplier, const T& increment, const T& modulus, const T& seed = prng::seed<T>)
			: _multiplier(multiplier), _increment(increment), _modulus(modulus), _seed(seed) {
			if (_multiplier == 0) throw std::invalid_argument("multiplier must be greater than 0");
			if (_modulus == 0) throw std::invalid_argument("modulus must be greater than 0");
		}
		~LinearCongruential(void) = default;
		T next() override {
			return _seed = (_multiplier * _seed + _increment) % _modulus;
		}
	protected:
		T _multiplier, _increment, _modulus, _seed;
	};
}
