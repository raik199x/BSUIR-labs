#pragma once

#include <backend/PRNG.hpp>

#include <backend/magic.hpp>

namespace prng {
	template <typename T, typename X, bool force = false>
		requires force || (bit::magic::bitsize<X> == 2 * bit::magic::bitsize<T>)
	class MiddleSquare : public IGenerator<T> {
	public:
		MiddleSquare(const T& seed = prng::seed<T>) : IGenerator<T>(), _seed(seed) {
			if (_seed == 0) throw std::invalid_argument("seed must be greater than 0");
		}
		~MiddleSquare() = default;
		T next() override {
			const X square = static_cast<X>(_seed) * static_cast<X>(_seed);
			const X middle = bit::magic::middle_bits<X>(square);
			return _seed = static_cast<T>(middle);
		}
	private:
		T _seed;
	};
}
