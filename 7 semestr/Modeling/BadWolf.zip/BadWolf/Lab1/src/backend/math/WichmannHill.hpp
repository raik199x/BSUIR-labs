#pragma once

#include <backend/PRNG.hpp>

#include <backend/math/Lehmer.hpp>

#include <cmath>

#include <iostream>

namespace prng {
	template <typename T, typename X = usize>
		requires std::is_floating_point_v<T>
	class WichmannHill : public IGenerator<T> {
	public:
		WichmannHill(const X& seed1, const X& seed2, const X& seed3)
			: IGenerator<T>(), _lehmer1(171, seed1, 30269), _lehmer2(172, seed2, 30307), _lehmer3(170, seed3, 30323) {
			if (seed1 == 0 || seed2 == 0 || seed3 == 0)
				throw std::invalid_argument("WichmannHill: seeds must be non-zero");
			if (seed1 >= 30000 || seed2 >= 30000 || seed3 >= 30000)
				throw std::invalid_argument("WichmannHill: seeds must be less than 30000");
		}
		~WichmannHill() = default;
		T next(void) override {
			T x1 = _lehmer1.next() / static_cast<T>(30269);
			T x2 = _lehmer2.next() / static_cast<T>(30307);
			T x3 = _lehmer3.next() / static_cast<T>(30323);
			return std::fmod<T>(x1 + x2 + x3, static_cast<T>(1));
		}
	private:
		Lehmer<X> _lehmer1;
		Lehmer<X> _lehmer2;
		Lehmer<X> _lehmer3;
	};
}
