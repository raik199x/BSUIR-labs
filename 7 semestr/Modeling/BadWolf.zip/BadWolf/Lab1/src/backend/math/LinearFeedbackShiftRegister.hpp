#pragma once

#include <backend/PRNG.hpp>

namespace prng {
	template <typename T>
	class LinearFeedbackShiftRegister : public IGenerator<T> {
	public:
		LinearFeedbackShiftRegister(const T& mask, const T& seed = prng::seed<T>) : _mask(mask), _seed(seed) {}
		~LinearFeedbackShiftRegister() = default;
		T next(void) {
			T lsb = _seed & 1;
			_seed >>= 1;
			if (lsb == 1) {
				_seed ^= _mask;
			}
			return _seed;
		}
	protected:
		T _mask, _seed;
	};
}
