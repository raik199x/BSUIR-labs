#pragma once

#include <backend/PRNG.hpp>

#include <functional>

namespace prng {
	// define lambda functions (+, -, *, /, %, ^) for T to use them as a parameter in the constructor
	template <typename T> static const std::function<T(T, T)> Additive = [](T a, T b) { return a + b; };
	template <typename T> static const std::function<T(T, T)> Subtractive = [](T a, T b) { return a - b; };
	template <typename T> static const std::function<T(T, T)> Multiplicative = [](T a, T b) { return a * b; };
	template <typename T> static const std::function<T(T, T)> BitwiseXOR = [](T a, T b) { return a ^ b; };

	template <typename T>
	class LaggedFibonacci : public IGenerator<T> {
	public:
		LaggedFibonacci(std::function<T(T, T)> mode, const std::vector<T>& initial, const usize& j, const usize& k, const T& module)
			: _operation(mode), _pool(initial), _j(j), _k(k), _module(module), _n(initial.size()) {
			if (_n == 0) throw std::invalid_argument("initial vector must not be empty");
			if (_j == 0) throw std::invalid_argument("j must be greater than 0");
			if (_k <= _j) throw std::invalid_argument("k must be greater than j");
			if (_k >= _n) throw std::invalid_argument("k must be less than n (size of initial)");
			if (module == 0) throw std::invalid_argument("module must be greater than 0");
		}
		~LaggedFibonacci() = default;
		T next(void) override {
			T Sn = _operation(_pool[_n - _j], _pool[_n - _k]) % _module;
			_pool.push_back(Sn);
			_pool.erase(_pool.begin());
			return Sn;
		}
	private:
		std::function<T(T, T)> _operation;
		std::vector<T> _pool;
		const usize _j;
		const usize _k;
		const T _module;
		const usize _n;
	};
}
