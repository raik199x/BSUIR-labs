#pragma once

#include <cmath>

#include <backend/math/LinearCongruential.hpp>

namespace prng {
	template <typename T>
	class InversiveCongruential : public LinearCongruential<T> {
	public:
		InversiveCongruential(const T& multiplier, const T& increment, const T& modulus, const T& seed = prng::seed<T>)
			: LinearCongruential<T>(multiplier, increment, modulus, seed) {
			// Check if the modulus is prime number
			if (is_prime(modulus) == false)
				throw std::runtime_error("Modulus must be a prime number");
		}
		~InversiveCongruential() = default;
		T next(void) override {
			#define seed LinearCongruential<T>::_seed
			#define increment LinearCongruential<T>::_increment
			#define modulus LinearCongruential<T>::_modulus
			#define multiplier LinearCongruential<T>::_multiplier
			if (seed == 0)
				return seed = increment;
			return seed = (multiplier * modular_inverse(seed, modulus) + increment) % modulus;
			#undef seed
			#undef increment
			#undef modulus
			#undef multiplier
		}
	private:
		T modular_inverse(const T& value, const T& modulus) {
			T a = value, m = modulus;
			T m0 = m, t, q;
			T x0 = 0, x1 = 1;
			while (a > 1) {
				q = a / m;
				t = m;
				m = a % m;
				a = t;
				t = x0;
				x0 = x1 - q * x0;
				x1 = t;
			}
			if (a != 1) {
				// Modular multiplicative inverse does not exist
				throw std::runtime_error("Modular multiplicative inverse does not exist");
			}
			// Make x1 positive
			while (x1 < 0) {
				x1 += m0;
			}
			return x1;
		}
		bool is_prime(const T& n) {
			if (n <= 1) {
				return false; // 0 and 1 are not prime numbers
			}
			if (n <= 3) {
				return true; // 2 and 3 are prime numbers
			}
			if (n % 2 == 0 || n % 3 == 0) {
				return false; // Numbers divisible by 2 or 3 are not prime
			}

			// Check for prime using 6k +/- 1 rule
			for (int i = 5; i * i <= n; i += 6) {
				if (n % i == 0 || n % (i + 2) == 0) {
					return false; // If divisible by any number in this range, not prime
				}
			}

			return true; // If no divisors found, it's prime
		}
	};
}
