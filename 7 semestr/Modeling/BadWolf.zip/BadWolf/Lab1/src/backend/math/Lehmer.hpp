#pragma once

#include <backend/math/LinearCongruential.hpp>

namespace prng {
	template <typename T>
	class Lehmer : public LinearCongruential<T> {
	public:
		Lehmer(const T& multiplier, const T& modulus, const T& seed = prng::seed<T>)
			: LinearCongruential<T>(multiplier, static_cast<T>(0), modulus, seed) {}
		~Lehmer(void) = default;
	};
}
