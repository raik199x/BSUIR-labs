#pragma once

#include <core/improve.hpp>

namespace bit::magic {
	using namespace cpp::improved;

	template <typename T>
	static constexpr usize bitsize = sizeof(T) * 8;

	template <typename T, typename X>
	static constexpr bool twice = bitsize<X> == 2 * bitsize<T>;

	template <typename T>
	usize meaningful_bits(const T& value) {
		// Count the number of zero bits on the left side of the value
		// Subtract the count from the total number of bits
		usize counter = 0;
		for (usize i = 0; i < bitsize<T>; ++i) {
			if ((value >> (bitsize<T> - i - 1)) & 0b1) break;
			++counter;
		}
		return bitsize<T> - counter;
	}

	template <typename T>
	T middle_bits(const T& value) {
		T result = value;
		const usize meaningful = meaningful_bits<T>(value);
		const usize half = meaningful / 2;
		const usize quarter = half / 2;
		result <<= quarter;
		result >>= half;
		return result;
	}
}
