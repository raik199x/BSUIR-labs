#pragma once

#include <backend/math/LinearFeedbackShiftRegister.hpp>
