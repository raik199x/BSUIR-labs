#pragma once

#include <backend/math/Lehmer.hpp>
