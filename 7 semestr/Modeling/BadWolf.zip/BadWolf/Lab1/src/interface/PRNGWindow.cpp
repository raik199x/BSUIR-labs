#include <interface/PRNGWindow.hpp>

#include <interface/literals.hpp>

using namespace cpp::improved;

PRNGWindow::PRNGWindow(const int algorithm, const int wrong_quantity, const PRNGParameter* const parameter, QWidget *parent) : QWidget(parent) {
	// Pre-configuration
	// setWindowTitle(literals::prng::title);
	// resize(1080, 720);

	// Clones
	clones.algorithm = algorithm;
	clones.quantity = wrong_quantity + 1;
	values = new u64[clones.quantity];

	// Parameters :: algorithm
	parameters.algorithm.prompt = new QLabel(literals::dropdown::prng);
	parameters.algorithm.value = new QLabel(literals::dropdown::options[algorithm]);
	parameters.algorithm.layout = new QHBoxLayout;
	parameters.algorithm.layout->addWidget(parameters.algorithm.prompt);
	parameters.algorithm.layout->addWidget(parameters.algorithm.value);

	// Parameters :: quantity
	parameters.quantity.prompt = new QLabel(literals::quantity::prng);
	parameters.quantity.value = new QLabel(QString::number(wrong_quantity));
	parameters.quantity.layout = new QHBoxLayout;
	parameters.quantity.layout->addWidget(parameters.quantity.prompt);
	parameters.quantity.layout->addWidget(parameters.quantity.value);

	// Parameters
	parameters.prompts = new QLabel(literals::prng::selected);
	parameters.layout = new QVBoxLayout;
	parameters.layout->addWidget(parameters.prompts);
	parameters.layout->addLayout(parameters.algorithm.layout);
	parameters.layout->addLayout(parameters.quantity.layout);

	// Options
	// options = new PRNGParameterTable(parameter);
	optional.prompt = new QLabel(literals::parameters::prng);
	optional.layout = new QVBoxLayout;
	optional.parameters = new PRNGParameterTable(parameter);
	optional.layout->addWidget(optional.prompt);
	optional.layout->addWidget(optional.parameters);

	// Tests
	tests = new NISTWidget();

	// Central components
	// central.widget = new QWidget;
	central.layout = new QVBoxLayout;
	// central.widget->setLayout(central.layout);
	central.layout->addLayout(parameters.layout);
	central.layout->addLayout(optional.layout);
	central.layout->addWidget(tests);

	// Layout
	setLayout(central.layout);

	// Connect signals and slots
}
PRNGWindow::~PRNGWindow(void) {
	// central.widget->deleteLater();
	central.layout->deleteLater();
	optional.layout->deleteLater();
	optional.parameters->deleteLater();
	optional.prompt->deleteLater();
	parameters.layout->deleteLater();
	parameters.prompts->deleteLater();
	for (auto& entity : {parameters.quantity, parameters.algorithm}) {
		entity.layout->deleteLater();
		entity.value->deleteLater();
		entity.prompt->deleteLater();
	}
	delete[] values;
	delete plot;
}

#include <backend/PRNG.hpp>
#include <backend/Lehmer.hpp>
#include <backend/MiddleProduct.hpp>
#include <backend/LinearFeedbackShiftRegister.hpp>

void PRNGWindow::generate(void) {
	switch (clones.algorithm) {
	case 0: {
		auto generator = prng::Lehmer<u64>(
			optional.parameters->options[0].value->text().toULongLong(),
			optional.parameters->options[1].value->text().toULongLong(),
			optional.parameters->options[2].value->text().toULongLong()
		);
		for (usize i = 0; i < clones.quantity; ++i) { values[i] = generator.next(); }
	} break;
	case 1: {
		auto generator = prng::MiddleProduct<u64, u128>(
			optional.parameters->options[0].value->text().toULongLong(),
			optional.parameters->options[1].value->text().toULongLong()
		);
		for (usize i = 0; i < clones.quantity; ++i) { values[i] = generator.next(); }
	} break;
	case 2: {
		auto generator = prng::LinearFeedbackShiftRegister<u64>(
			optional.parameters->options[0].value->text().toULongLong(),
			optional.parameters->options[1].value->text().toULongLong()
		);
		for (usize i = 0; i < clones.quantity; ++i) { values[i] = generator.next(); }
	} break;
	default:
		throw "Invalid Algorithm index";
	}
	tests->generated(values, clones.quantity);
	plot = BuildHistogramPlot(
		values , clones.quantity,
		GetMinimalValue(values , clones.quantity),
		GetMaximalValue(values , clones.quantity)
	);
	central.layout->addWidget(plot);

	// Theory
	std::mt19937_64                         generator(literals::constants::presets[2]);
	std::uniform_int_distribution<uint64_t> distribution(0, 0xFFFFFFFFFFFFFFFF);
	auto theory = new u64[clones.quantity];
	for (usize i = 0; i < clones.quantity; ++i) {
		theory[i] = distribution(generator);
	}

	// Mean and Dispersion
	mean.prompt = new QLabel("Mean: ");
	mean.layout = new QHBoxLayout;
	double theory_mean = calculateMean(theory, clones.quantity);
	mean.theory = new QLabel("Theoretical: " + QString::number(theory_mean));
	double practice_mean = calculateMean(values, clones.quantity);
	mean.practice = new QLabel("Practical: " + QString::number(practice_mean));
	mean.layout->addWidget(mean.theory);
	mean.layout->addWidget(mean.practice);

	dispersion.prompt = new QLabel("Dispersion: ");
	dispersion.layout = new QHBoxLayout;
	double theory_dispersion = calculateDispersion(theory, clones.quantity, theory_mean);
	dispersion.theory = new QLabel("Theoretical: " + QString::number(theory_dispersion));
	double practice_dispersion = calculateDispersion(values, clones.quantity, practice_mean);
	dispersion.practice = new QLabel("Practical: " + QString::number(practice_dispersion));
	dispersion.layout->addWidget(dispersion.theory);
	dispersion.layout->addWidget(dispersion.practice);

	central.layout->addWidget(mean.prompt);
	central.layout->addLayout(mean.layout);
	central.layout->addWidget(dispersion.prompt);
	central.layout->addLayout(dispersion.layout);

	delete[] theory;
}
