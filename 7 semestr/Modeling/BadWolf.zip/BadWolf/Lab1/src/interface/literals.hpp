#pragma once

#include <core/improve.hpp>

#define literal static constexpr const char* const

static constexpr const auto PRNG_OPTIONS = 3;

namespace literals::main {
	literal title = "Modeling - Lab 1 - PRNG: Algorithms and Parameters";
}

namespace literals::dropdown {
	literal prompt = "A. Select PRNG Algorithm";
	literal title = "Dropdown";
	literal options[PRNG_OPTIONS] = {
		"Lehmer",
		"Middle Product",
		"Linear Feedback Shift Register",

		// "Middle Square",
		// "Linear Congruential",
		// "Lagged Fibonacci", "Wichmann–Hill",
		// "Rule30",
		// "Inversive congruential generator",
	};
	literal prng = "A. Selected PRNG Algorithm";
}

namespace literals::quantity {
	literal prompt = "B. Specify the quantity of generated numbers";
	literal prng = "B. The specified quantity of generated numbers";
}

namespace literals::parameters {
	literal prompt = "C. Provide specific parameters for PRNG Algorithm";
	static constexpr const cpp::improved::usize LIMIT = 6;
	literal options[PRNG_OPTIONS][LIMIT] = {
		{ "multiplier", "modulus", "seed" },
		{ "seed0", "seed1" },
		{ "mask", "seed" },

		// { "seed" },
		// { "multiplier", "increment", "modulus", "seed" },
		// "Lagged Fibonacci", "Wichmann–Hill",
		// { "seed" },
		// { "multiplier", "increment", "modulus", "seed" },
	};
	literal prng = "C. Specific parameters for PRNG Algorithm";
}

namespace literals::generate {
	literal prompt = "D. Run PRNG Algorithm with specified parameters";
	literal button = "Generate";
}

namespace literals::prng {
	literal title = "Modeling - Lab 1 - PRNG: Generation and Testing";
	literal selected = "Running configuration:";
}

namespace literals::constants {
	static constexpr const cpp::improved::u64 presets[3] = {
		18446744073709551031ULL,
		18446744073709551577ULL,
		18446744073709550719ULL
	};
}