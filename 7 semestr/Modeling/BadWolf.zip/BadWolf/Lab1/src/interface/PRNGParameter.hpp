#pragma once

#include <core/improve.hpp>

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>

class PRNGParameter : public QWidget {
	friend class PRNGParameterTable;
	Q_OBJECT
public:
	PRNGParameter(const cpp::improved::str* const argv);
	~PRNGParameter(void);
private:
	cpp::improved::usize argc = 0;
	QVBoxLayout* layout = nullptr;
	typedef struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QLineEdit* box = nullptr;
	} Option;
	Option* options = nullptr;
};

class PRNGParameterTable : public QWidget {
	friend class PRNGWindow;
	Q_OBJECT
public:
	PRNGParameterTable(const PRNGParameter* const parameter);
	~PRNGParameterTable(void);
private:
	cpp::improved::usize argc = 0;
	QVBoxLayout* layout = nullptr;
	typedef struct {
		QHBoxLayout* layout;
		QLabel* prompt;
		QLabel* value;
	} Option;
	Option* options = nullptr;
};
