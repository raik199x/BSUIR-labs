#include <QApplication>

#include <frontend/seeker.hpp>
#include <interface/MainWindow.hpp>

int main(int argc, char* argv[]) {
	seeker(30);
	QApplication app(argc, argv);
	MainWindow window;
	window.show();
	return app.exec();
}
