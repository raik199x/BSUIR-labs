#include <interface/PRNGParameter.hpp>
#include <interface/literals.hpp>
using namespace cpp::improved;

#include <iostream>
#include <format>

PRNGParameter::PRNGParameter(const str* const argv) {
	// Argc + argv
	for (; argv[argc] != nullptr; ++argc) {}
	std::cerr << std::format("{} argc = {}, argv =", '{', argc);
	for (usize i = 0; i < argc; ++i)
		std::cerr << " " << argv[i];
	std::cerr << " }" << std::endl;

	// Layout
	layout = new QVBoxLayout;

	// Options
	options = new Option[argc];
	for (usize i = 0; i < argc; ++i) {
		options[i].layout = new QHBoxLayout;
		options[i].prompt = new QLabel(("\tC." + std::to_string(i) + " '" + argv[i] + "':").c_str());
		options[i].box = new QLineEdit;
		options[i].box->setText(QString::number(literals::constants::presets[i]));
		options[i].layout->addWidget(options[i].prompt);
		options[i].layout->addWidget(options[i].box);
		layout->addLayout(options[i].layout);
	}

	// Components
	setLayout(layout);
}

PRNGParameter::~PRNGParameter() {
	for (usize i = 0; i < argc; ++i) {
		delete options[i].layout;
		delete options[i].prompt;
		delete options[i].box;
	}
	delete[] options;
}

PRNGParameterTable::PRNGParameterTable(const PRNGParameter* const parameter) {
	// Argc
	argc = parameter->argc;
	// Layout
	layout = new QVBoxLayout;

	// Options
	options = new Option[argc];
	for (usize i = 0; i < argc; ++i) {
		options[i].layout = new QHBoxLayout;
		options[i].prompt = new QLabel(parameter->options[i].prompt->text());
		options[i].value = new QLabel(QString::number(parameter->options[i].box->text().toULongLong()));
		options[i].layout->addWidget(options[i].prompt);
		options[i].layout->addWidget(options[i].value);
		layout->addLayout(options[i].layout);
	}

	// Components
	setLayout(layout);
}

PRNGParameterTable::~PRNGParameterTable() {
	for (usize i = 0; i < argc; ++i) {
		delete options[i].layout;
		delete options[i].prompt;
		delete options[i].value;
	}
	delete[] options;
}
