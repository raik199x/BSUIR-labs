#include <interface/MainWindow.hpp>

#include <core/improve.hpp>
using namespace cpp::improved;

static constexpr const int E8 = 100000000ULL;

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
	// Pre-configuration
	setWindowTitle(literals::main::title);
	resize(1080, 720);

	// Dropdown
	dropdown.layout = new QHBoxLayout;
	dropdown.prompt = new QLabel(literals::dropdown::prompt);
	dropdown.menu = new QComboBox;
	usize index = 0;
	dropdown.menu->addItem(literals::dropdown::title);
	for (const auto& option : literals::dropdown::options)
		dropdown.menu->addItem((std::to_string(++index) + ". " + option).c_str());
	dropdown.layout->addWidget(dropdown.prompt);
	dropdown.layout->addWidget(dropdown.menu);

	// Quantity
	quantity.layout = new QHBoxLayout;
	quantity.prompt = new QLabel(literals::quantity::prompt);
	quantity.box = new QLineEdit;
	quantity.box->setText(QString::number(E8));
	quantity.layout->addWidget(quantity.prompt);
	quantity.layout->addWidget(quantity.box);

	// Parameters
	parameters.layout = new QVBoxLayout;
	parameters.prompt = new QLabel(literals::parameters::prompt);
	parameters.layout->addWidget(parameters.prompt);
	for (usize i = 0; i < PRNG_OPTIONS; ++i) {
		parameters.options[i] = new PRNGParameter(literals::parameters::options[i]);
		parameters.options[i]->hide();
		parameters.layout->addWidget(parameters.options[i]);
	}

	// Generate Button
	generate.layout = new QHBoxLayout;
	generate.prompt = new QLabel(literals::generate::prompt);
	generate.button = new QPushButton(literals::generate::button);
	generate.layout->addWidget(generate.prompt);
	generate.layout->addWidget(generate.button);

	// Central components
	central.widget = new QWidget;
	central.layout = new QVBoxLayout;
	central.halfs = new QHBoxLayout;
	central.widget->setLayout(central.halfs);
	central.layout->addLayout(dropdown.layout);
	central.layout->addLayout(quantity.layout);
	central.layout->addLayout(parameters.layout);
	central.layout->addLayout(generate.layout);
	central.halfs->addLayout(central.layout);
	setCentralWidget(central.widget);

	// Connect signals and slots
	connect(dropdown.menu, SIGNAL(currentIndexChanged(int)), this, SLOT(upon_dropdown_change(int)));
	connect(generate.button, SIGNAL(clicked()), this, SLOT(upon_generate_button()));
}

MainWindow::~MainWindow(void) {
	generate.button->deleteLater();
	generate.prompt->deleteLater();
	generate.layout->deleteLater();
	for (usize i = 0; i < PRNG_OPTIONS; ++i)
		parameters.options[i]->deleteLater();
	parameters.prompt->deleteLater();
	parameters.layout->deleteLater();
	quantity.box->deleteLater();
	quantity.prompt->deleteLater();
	quantity.layout->deleteLater();
	dropdown.menu->deleteLater();
	dropdown.prompt->deleteLater();
	dropdown.layout->deleteLater();
	central.layout->deleteLater();
	central.widget->deleteLater();
}

void MainWindow::upon_dropdown_change(int new_index) {
	if (new_index == 0) {
		// Restore old index
		dropdown.menu->setCurrentIndex(dropdown.old_index + 1);
		return;
	}
	// Fix index
	--new_index;
	// Else hide parameters.options[old_index] and show parameters.options[new_index]
	parameters.options[dropdown.old_index]->hide();
	parameters.options[new_index]->show();
	dropdown.old_index = new_index;
}

#include <iostream>
void MainWindow::upon_generate_button(void) {
	if (dropdown.menu->currentIndex() == 0)
		return;
	const auto index = dropdown.menu->currentIndex() - 1;

	if (widget != nullptr) {
		central.halfs->removeWidget(widget);
		delete widget;
	}
	widget = new PRNGWindow(index, quantity.box->text().toULongLong(), parameters.options[index], this);
	widget->generate();
	central.halfs->addWidget(widget);
}
