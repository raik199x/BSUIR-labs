#pragma once

#include <interface/literals.hpp>

#include <QMainWindow>

#include <QWidget>
#include <QLabel>
#include <QComboBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QLineEdit>

#include <interface/PRNGParameter.hpp>
#include <interface/PRNGWindow.hpp>

class MainWindow : public QMainWindow {
	Q_OBJECT
public:
	MainWindow(QWidget *parent = nullptr);
	~MainWindow(void);
private slots:
	// Slot for QComboBox
	void upon_dropdown_change(int new_index);
	// Slop for QPushButton
	void upon_generate_button(void);
private:
	// Central components
	struct {
		QWidget* widget = nullptr;
		QVBoxLayout* layout = nullptr;
		QHBoxLayout* halfs = nullptr;
	} central;
	// Dropdown
	struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QComboBox* menu = nullptr;
		int old_index = 0;
	} dropdown;
	// Number of generated numbers
	struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QLineEdit* box = nullptr;
	} quantity;
	// Parameters
	struct {
		QVBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		PRNGParameter* options[PRNG_OPTIONS];
	} parameters;
	// Generate Button
	struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QPushButton* button = nullptr;
	} generate;
	// PRNG Widget
	PRNGWindow* widget = nullptr;
};
