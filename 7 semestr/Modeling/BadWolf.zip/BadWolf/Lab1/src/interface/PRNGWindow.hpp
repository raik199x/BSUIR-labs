#pragma once

#include <QWidget>
#include <QLabel>
#include <QComboBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSpinBox>
#include <QPushButton>

#include <interface/PRNGParameter.hpp>
#include <frontend/NISTWidget.hpp>

#include <libs/nist/Operations.h>

class PRNGWindow : public QWidget {
	Q_OBJECT
public:
	PRNGWindow(const int algorithm, const int quantity, const PRNGParameter* const parameter, QWidget *parent = nullptr);
	~PRNGWindow(void);

	void generate(void);
private:
	// Clones
	struct {
		cpp::improved::usize algorithm = 0;
		cpp::improved::usize quantity = 0;
	} clones;
	cpp::improved::u64* values = nullptr;
	// Central components
	struct {
		// QWidget* widget = nullptr;
		QVBoxLayout* layout = nullptr;
	} central;
	// Parameters
	struct {
		QLabel* prompts = nullptr;
		QVBoxLayout* layout = nullptr;
		struct {
			QLabel* prompt = nullptr;
			QLabel* value = nullptr;
			QHBoxLayout* layout = nullptr;
		} algorithm, quantity;
	} parameters;
	// Options
	struct {
		QLabel* prompt = nullptr;
		QVBoxLayout* layout = nullptr;
		PRNGParameterTable* parameters = nullptr;
	} optional;
	// NIST
	NISTWidget* tests = nullptr;
	// Plot
	QCustomPlot* plot = nullptr;
	// Mean and dispersion
	struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QLabel* theory = nullptr;
		QLabel* practice = nullptr;
	} mean, dispersion;
};
