#include <frontend/NISTWidget.hpp>

#include <filesystem>

using namespace cpp::improved;

NISTWidget::NISTWidget(void) {
	// Layout
	layout = new QVBoxLayout;

	// Prompt
	prompt = new QLabel(literals::NISTs::prompt);
	layout->addWidget(prompt);

	// Tests
	tests = new Test[literals::NISTs::TESTS];
	for (usize i = 0; i < literals::NISTs::TESTS; ++i) {
		tests[i].layout = new QHBoxLayout;
		tests[i].prompt = new QLabel(literals::NISTs::tests[i]);
		tests[i].status = new QLabel(literals::NISTs::status::untested);
		tests[i].layout->addWidget(tests[i].prompt);
		tests[i].layout->addWidget(tests[i].status);
		layout->addLayout(tests[i].layout);
	}
	// Button
	button = new QPushButton(literals::NISTs::run);
	button->setDisabled(true);
	layout->addWidget(button);

	// Status
	status = new QLabel(literals::NISTs::status::generating);
	layout->addWidget(status);

	// Components
	setLayout(layout);

	// Connect signals and slots
	connect(button, SIGNAL(clicked()), this, SLOT(upon_test_button()));
}

NISTWidget::~NISTWidget(void) {
	// 	QVBoxLayout* layout = nullptr;
	// QLabel* prompt = nullptr;
	// typedef struct {
	// 	QHBoxLayout* layout = nullptr;
	// 	QLabel* prompt = nullptr;
	// 	QLabel* status = nullptr;
	// 	QPushButton* button = nullptr;
	// } Test;
	// Test* tests = nullptr;
}

void NISTWidget::generated(const cpp::improved::u64* const values, const cpp::improved::usize size) {
	this->values = values;
	this->size = size;
	status->setText(literals::NISTs::status::generated);
	button->setEnabled(true);
}

#include <libs/nist.hpp>

static constexpr const u16 BLOCKS = 1000;

QString NISTWidget::create_status(const bool state) {
	return state ? literals::NISTs::status::passed : literals::NISTs::status::failed;
}

void NISTWidget::upon_test_button(void) {
	status->setText(literals::NISTs::status::running);
	const bool result0 = FrequencyMonobitTest(values, size);
	tests[0].status->setText(create_status(result0));
	const bool result1 = FrequencyBlockTest(values, size, BLOCKS);
	tests[1].status->setText(create_status(result1));
	const bool result2 = TestForSequenceOfIdenticalBits(values, size);
	tests[2].status->setText(create_status(result2));
	const bool result3 = TestForLongestRunOfOnesInABlock(values, size, BLOCKS);
	tests[3].status->setText(create_status(result3));
	const bool result4 = BinaryMatrixRankTest(values, size);
	tests[4].status->setText(create_status(result4));
	const bool result5 = SpectrumTest(values, size);
	tests[5].status->setText(create_status(result5));
	const bool result6 = NonOverlappingTemplateMatchingTest(values, size, "/run/media/timurialvarez/SeagateRoot/Home/Public/BSUIR/Modelling/Term7/Lab1/data/template.txt");
	tests[6].status->setText(create_status(result6));
	const bool result7 = OverlappingTemplateMatchingTest(values, size, "/run/media/timurialvarez/SeagateRoot/Home/Public/BSUIR/Modelling/Term7/Lab1/data/template.txt");
	tests[7].status->setText(create_status(result7));
	status->setText(literals::NISTs::status::done);
}

// void NISTWidget::upon_test_button_0(void) {
// 	status->setText(literals::NISTs::status::running);
// 	const bool result = FrequencyMonobitTest(values, size);
// 	tests[0].status->setText(create_status(result));
// }
// void NISTWidget::upon_test_button_1(void) {
// 	status->setText(literals::NISTs::status::running);
// }
// void NISTWidget::upon_test_button_2(void) {
// 	status->setText(literals::NISTs::status::running);
// }
// void NISTWidget::upon_test_button_3(void) {
// 	status->setText(literals::NISTs::status::running);
// }
// void NISTWidget::upon_test_button_4(void) {
// 	status->setText(literals::NISTs::status::running);
// }
// void NISTWidget::upon_test_button_5(void) {
// 	status->setText(literals::NISTs::status::running);
// }
// void NISTWidget::upon_test_button_6(void) {
// 	status->setText(literals::NISTs::status::running);
// }
// void NISTWidget::upon_test_button_7(void) {
// 	status->setText(literals::NISTs::status::running);
// }
