#pragma once

#include <core/improve.hpp>

#include <iostream>
#include <format>

inline auto is_prime(const cpp::improved::u64 n) {
	if (n <= 1) {
		return false; // 0 and 1 are not prime numbers
	}
	if (n <= 3) {
		return true; // 2 and 3 are prime numbers
	}
	if (n % 2 == 0 || n % 3 == 0) {
		return false; // Numbers divisible by 2 or 3 are not prime
	}

	// Check for prime using 6k +/- 1 rule
	for (int i = 5; i * i <= n; i += 6) {
		if (n % i == 0 || n % (i + 2) == 0) {
			return false; // If divisible by any number in this range, not prime
		}
	}

	return true; // If no divisors found, it's prime
}

template<typename T>
inline auto true_seeker(const cpp::improved::usize quantity) -> void {
	cpp::improved::usize counter = 0;
	T number = std::numeric_limits<T>::max();
	while (true) {
		if (is_prime(number)) {
			std::cout << std::format("{0}\n", number);
			++counter;
		}
		if (counter >= quantity)
			return;
		--number;
	}
}

inline auto seeker(const cpp::improved::usize quantity) -> void {
	true_seeker<cpp::improved::u64>(quantity);
	std::cout << std::endl;
	std::cout << std::format("{0}\n", 18446744073709551031ULL);
	std::cout << std::format("{0}\n", 18446744073709551577ULL);
	std::cout << std::format("{0}\n", 18446744073709550719ULL);
}

// 18446744073709551031ULL
// 18446744073709551577ULL
// 18446744073709550719ULL
