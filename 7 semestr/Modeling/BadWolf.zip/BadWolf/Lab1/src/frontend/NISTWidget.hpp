#pragma once

#include <core/improve.hpp>

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QStyle>
#include <QPushButton>

#include <frontend/literals.hpp>

class NISTWidget : public QWidget {
	Q_OBJECT
public:
	NISTWidget(void);
	~NISTWidget(void);
	void generated(const cpp::improved::u64* const values, const cpp::improved::usize size);
private:
	const cpp::improved::u64* values = nullptr;
	cpp::improved::usize size = 0;
	QVBoxLayout* layout = nullptr;
	QLabel* prompt = nullptr;
	typedef struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QLabel* status = nullptr;
	} Test;
	QPushButton* button = nullptr;
	Test* tests = nullptr;
	QLabel* status = nullptr;
public slots:
	void upon_test_button(void);
protected:
	QString create_status(const bool state);
};
