#include <interface/literals.hpp>

namespace literals::NISTs {
	static constexpr const cpp::improved::usize TESTS = 8;
	literal prompt = "NIST tests:";
	literal tests[TESTS] {
		"Frequency monobit test",
		"Frequency block test",
		"Test on selection of similar bits",
		"Test for the longest run of ones",
		"Test of matrix ranks",
		"Spectrum test",
		"Non-overlapping matching test templates",
		"Overlapping pattern matching test",
	};
	literal run = "Run";
}

namespace literals::NISTs::status {
	literal untested = "Untested";
	literal generating = "Generating...";
	literal generated = "Generated!";
	literal running = "Running...";
	literal passed = "Passed";
	literal failed = "Failed";
	literal done = "Testing is done. Ready to run again.";
}
