#pragma once

#include <cstdint>

#include <string>
#include <string_view>

namespace cpp::improved {
	using i8 = std::int8_t;
	using i16 = std::int16_t;
	using i32 = std::int32_t;
	using i64 = std::int64_t;
	using isize = i64;

	using u8 = std::uint8_t;
	using u16 = std::uint16_t;
	using u32 = std::uint32_t;
	using u64 = std::uint64_t;
	using usize = u64;

	using f32 = float;
	using f64 = double;
	using f128 = long double;

	#if defined(__SIZEOF_INT128__)
		using i128 = __int128_t;
		using u128 = __uint128_t;
	#endif

	using str = const char*;
}
