#pragma once

#include <common/core/types.hpp>

/// @brief References: [torvalds/linux/lib/random32.c](https://github.com/torvalds/linux/blob/master/lib/random32.c).
class Tausworthe32 {
public:
	Tausworthe32(const u32 seed, const usize depth);
	Tausworthe32(const u32 state1, const u32 state2, const u32 state3, const u32 state4);
	~Tausworthe32(void) = default;
	u32 next(void);
private:
	u32 s1, s2, s3, s4;
};
