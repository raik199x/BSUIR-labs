// SPDX-License-Identifier: GPL-2.0
/// @brief References: [torvalds/linux/lib/random32.c](https://github.com/torvalds/linux/blob/master/lib/random32.c).

#include <stdexcept>

#include <libs/linux/Tausworthe32.hpp>

#define TAUSWORTHE(s, a, b, c, d) ((s & c) << d) ^ (((s << a) ^ s) >> b)
Tausworthe32::Tausworthe32(
	const u32 seed,
	const usize depth
) {
	if (!(seed > 127)) throw std::invalid_argument("seed must be greater that 127");
	Tausworthe32 tausworthe(seed, seed, seed, seed);
	for (usize i = 0; i < depth; i++) {
		tausworthe.next();
	}
	s1 = tausworthe.next();
	s2 = tausworthe.next();
	s3 = tausworthe.next();
	s4 = tausworthe.next();
}

Tausworthe32::Tausworthe32(
	const u32 state1,
	const u32 state2,
	const u32 state3,
	const u32 state4
) : s1(state1), s2(state2), s3(state3), s4(state4) {
	if (!(s1 > 1))   throw std::invalid_argument("s1 must be greater that 1");
	if (!(s2 > 7))   throw std::invalid_argument("s2 must be greater that 7");
	if (!(s3 > 15))  throw std::invalid_argument("s3 must be greater that 15");
	if (!(s4 > 127)) throw std::invalid_argument("s4 must be greater that 127");
}

u32 Tausworthe32::next(void) {
	s1 = TAUSWORTHE(s1,  6U, 13U, 4294967294U, 18U);
	s2 = TAUSWORTHE(s2,  2U, 27U, 4294967288U,  2U);
	s3 = TAUSWORTHE(s3, 13U, 21U, 4294967280U,  7U);
	s4 = TAUSWORTHE(s4,  3U, 12U, 4294967168U, 13U);
	return (s1 ^ s2 ^ s3 ^ s4);
}

#undef TAUSWORTHE
