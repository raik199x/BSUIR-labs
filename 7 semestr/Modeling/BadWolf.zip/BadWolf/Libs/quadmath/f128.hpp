#pragma once

#include <string>
#include <ostream>

#include <common/core/types.hpp>

namespace std {
	std::string to_string(const f128& value);
	f128 stof128(const std::string& string);
}

std::ostream& operator<<(std::ostream& os, const f128& value);
