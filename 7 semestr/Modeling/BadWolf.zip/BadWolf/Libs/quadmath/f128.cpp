#include <sstream>
#include <stdexcept>

#include <quadmath.h>

#include <libs/quadmath/f128.hpp>

std::string std::to_string(const f128& value) {
	char buffer[128]; // Adjust the size as needed
	quadmath_snprintf(buffer, sizeof(buffer), "%.32QE", value);
	return std::string(buffer);
}

f128 std::stof128(const std::string& string) {
	const char* const str = string.c_str();
	char* end;
	const f128 value = strtoflt128(str, &end);
	if (end == str)
		throw std::logic_error("Failed to convert `" + string + "` to f128");
	return value;
}

std::ostream& operator<<(std::ostream& os, const f128& value) {
	os << std::to_string(value);
	return os;
}
