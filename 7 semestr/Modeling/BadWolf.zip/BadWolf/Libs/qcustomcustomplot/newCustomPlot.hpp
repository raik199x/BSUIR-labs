#pragma once

#include "qcustomplot.h"

template <typename T>
T min(const QVector<T> values) {
	const usize size = values.size();
	usize min_index = 0;
	for (usize i = 1; i < size; ++i) {
		if (values.at(i) < values.at(min_index)) {
			min_index = i;
		}
	}
	return values.at(min_index);
}
template <typename T>
T max(const QVector<T> values) {
	const usize size = values.size();
	usize max_index = 0;
	for (usize i = 1; i < size; ++i) {
		if (values.at(i) > values.at(max_index)) {
			max_index = i;
		}
	}
	return values.at(max_index);
}

template <typename T>
QCustomPlot *newCustomPlot(const QVector<T> x, const QVector<T> y) {
	static constexpr const T OFFSET = 0.5;
	const T minX = min(x) - OFFSET;
	const T maxX = max(x) + OFFSET;
	const T minY = min(y) - OFFSET;
	const T maxY = max(y) + OFFSET;
	QCustomPlot *customPlot = new QCustomPlot;

	// Check if the x and y vectors have the same size
	if (x.size() != y.size()) {
		QMessageBox::warning(nullptr, "Warning",
												 "Vector sizes (x,y) are not the same!");
		return nullptr;
	}

	// create and configure plottables
	QCPGraph *Points = customPlot->addGraph();
	Points->setPen(QPen(QColor(120, 120, 120), 2));
	Points->setScatterStyle(QCPScatterStyle(
			QCPScatterStyle::ssCircle, QPen(Qt::black, 1.5), QBrush(Qt::white), 9));
	Points->setData(x, y);
	// Points->setSmooth(true);
	Points->setLineStyle(QCPGraph::lsLine);

	// Customizing ui of graphic
	customPlot->xAxis->setBasePen(QPen(Qt::white, 1));
	customPlot->yAxis->setBasePen(QPen(Qt::white, 1));
	customPlot->xAxis->setTickPen(QPen(Qt::white, 1));
	customPlot->yAxis->setTickPen(QPen(Qt::white, 1));
	customPlot->xAxis->setSubTickPen(QPen(Qt::white, 1));
	customPlot->yAxis->setSubTickPen(QPen(Qt::white, 1));
	customPlot->xAxis->setTickLabelColor(Qt::white);
	customPlot->yAxis->setTickLabelColor(Qt::white);
	customPlot->xAxis->grid()->setPen(
			QPen(QColor(140, 140, 140), 1, Qt::DotLine));
	customPlot->yAxis->grid()->setPen(
			QPen(QColor(140, 140, 140), 1, Qt::DotLine));
	customPlot->xAxis->grid()->setSubGridPen(
			QPen(QColor(80, 80, 80), 1, Qt::DotLine));
	customPlot->yAxis->grid()->setSubGridPen(
			QPen(QColor(80, 80, 80), 1, Qt::DotLine));
	customPlot->xAxis->grid()->setSubGridVisible(true);
	customPlot->yAxis->grid()->setSubGridVisible(true);
	customPlot->xAxis->grid()->setZeroLinePen(Qt::NoPen);
	customPlot->yAxis->grid()->setZeroLinePen(Qt::NoPen);
	customPlot->xAxis->setUpperEnding(QCPLineEnding::esSpikeArrow);
	customPlot->yAxis->setUpperEnding(QCPLineEnding::esSpikeArrow);
	QLinearGradient plotGradient;
	plotGradient.setStart(0, 0);
	plotGradient.setFinalStop(0, 350);
	plotGradient.setColorAt(0, QColor(80, 80, 80));
	plotGradient.setColorAt(1, QColor(50, 50, 50));
	customPlot->setBackground(plotGradient);
	QLinearGradient axisRectGradient;
	axisRectGradient.setStart(0, 0);
	axisRectGradient.setFinalStop(0, 350);
	axisRectGradient.setColorAt(0, QColor(80, 80, 80));
	axisRectGradient.setColorAt(1, QColor(30, 30, 30));
	customPlot->axisRect()->setBackground(axisRectGradient);

	customPlot->xAxis->setRange(minX, maxX);
	customPlot->yAxis->setRange(minY, maxY);
	return customPlot;
}
