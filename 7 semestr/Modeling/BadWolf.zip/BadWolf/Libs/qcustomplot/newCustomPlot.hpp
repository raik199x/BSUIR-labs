#pragma once

#include <common/backend/statistics.hpp>

#include <libs/qcustomplot/newEmptyPlot.hpp>

template <typename T>
QCustomPlot* newCustomPlot(const QString& title, const QString& labelX, const QString& labelY, const T* const values, const usize size) {
	const T minimal = statistics::min(values, size);
	const T maximal = statistics::max(values, size);
	// Building plot
	QCustomPlot *plot = new QCustomPlot();
	// Create bars for the histogram
	QCPBars *bars = new QCPBars(plot->xAxis, plot->yAxis);
	// Set up for a bar chart
	bars->setWidth(0.0);
	bars->setPen(QPen(Qt::blue));
	bars->setBrush(QBrush(QColor(0, 0, 255, 20)));
	// Building data for histogram
	const usize numBins = 512; // Adjust the number of bins as needed
	// Calculate bin width
	double binWidth = static_cast<double>(maximal - minimal) / numBins;
	// Initialize bins
	std::vector<uint64_t> bins(numBins, 0);
	// Count occurrences in each bin
	for (usize i = 0; i < size; ++i) {
		// Determine the bin for the current value
		usize binIndex = static_cast<usize>((values[i] - minimal) / binWidth);
		// Increment the corresponding bin
		bins[binIndex]++;
	}
	// Set the data for bars
	QVector<double> xData, yData;
	for (usize i = 0; i < numBins; ++i) {
		double binCenter = minimal + (i + 0.5) * binWidth;
		xData.push_back(binCenter);
		yData.push_back(bins[i]);
	}
	bars->setData(xData, yData);
	// Setting axes
	plot->xAxis->setLabel(labelX);
	plot->yAxis->setLabel(labelY);
	// Setting y-axis range
	plot->yAxis->setRange(0, *std::max_element(yData.begin(), yData.end())); // Adjusted the y-axis range
	plot->xAxis->setRange(minimal, maximal);
	// Setting legend
	plot->legend->setVisible(true);
	bars->setName(title);
	// Setting plot title
	plot->plotLayout()->insertRow(0);
	plot->plotLayout()->addElement(0, 0, new QCPTextElement(plot, title, QFont("sans", 12, QFont::Bold)));
	// Setting plot size
	plot->setMinimumSize(1280, 720);
	plot->replot();
	// Returning plot
	return plot;
}
