#pragma once

#include <numeric>

#include <qcustomplot.h>

template <typename T>
QCustomPlot* newEmptyPlot(const QString& title, const QString& labelX, const QString& labelY) {
	// Building plot
	QCustomPlot *plot = new QCustomPlot();
	// Create bars for the histogram
	QCPBars *bars = new QCPBars(plot->xAxis, plot->yAxis);
	// Set up for a bar chart
	bars->setPen(QPen(Qt::blue));
	bars->setBrush(QBrush(QColor(0, 0, 255, 20)));
	// Setting axes
	plot->xAxis->setLabel(labelX);
	plot->yAxis->setLabel(labelY);
	// Setting y-axis range
	plot->yAxis->setRange(0, std::numeric_limits<T>::max());
	plot->xAxis->setRange(0, std::numeric_limits<T>::max());
	// Setting legend
	plot->legend->setVisible(true);
	bars->setName(title);
	// Setting plot title
	plot->plotLayout()->insertRow(0);
	plot->plotLayout()->addElement(0, 0, new QCPTextElement(plot, title, QFont("sans", 12, QFont::Bold)));
	// Setting plot size
	plot->setMinimumSize(1280, 720);
	plot->replot();
	// Returning plot
	return plot;
}
