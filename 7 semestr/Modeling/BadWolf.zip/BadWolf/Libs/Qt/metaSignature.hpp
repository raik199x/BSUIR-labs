#pragma once

#include <QMetaMethod>

QByteArray metaSignature(const QMetaMethod& method);
