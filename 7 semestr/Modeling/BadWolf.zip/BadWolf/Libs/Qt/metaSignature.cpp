#include <libs/Qt/metaSignature.hpp>

QByteArray metaSignature(const QMetaMethod& method) {
	QByteArray result = method.typeName();
	result += ' ' + method.name() + '(';
	bool first = true;
	for (auto el : method.parameterTypes()) {
		if (!first) result += ", ";
		else first = false;
		result += el;
	}
	result += ')';
	return result;
}
