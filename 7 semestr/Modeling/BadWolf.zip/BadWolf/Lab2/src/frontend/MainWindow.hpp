#pragma once

#include <QMainWindow>
#include <QHBoxLayout>

#include <common/core/types.hpp>
#include <interface/RequestWidget.hpp>
#include <interface/ResponseWidget.hpp>

class MainWindow : public QMainWindow {
	Q_OBJECT
public:
	MainWindow(QWidget* const parent = nullptr);
	~MainWindow(void);
private:
	// Central components
	struct {
		QWidget* widget = nullptr;
		QHBoxLayout* layout = nullptr;
	} central;
	// Request Widget
	RequestWidget* request = nullptr;
	// Response Widget
	QWidget* placeholder = nullptr;
	ResponseWidget* response = nullptr;
private slots:
	void accept(u64*, usize, f128, f128);
};
