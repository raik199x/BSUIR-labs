#include <frontend/MainWindow.hpp>
#include <interface/literals.hpp>

MainWindow::MainWindow(QWidget* const parent) : QMainWindow(parent) {
	// Widget and layouts
	central.widget = new QWidget;
	central.layout = new QHBoxLayout;
	// Request Widget
	request = new RequestWidget;
	central.layout->addWidget(request, 1);
	// Response Widget
	placeholder = new QWidget;
	central.layout->addWidget(placeholder, 2);
	// Central components
	central.widget->setLayout(central.layout);
	setCentralWidget(central.widget);
	// Window configuration
	setWindowTitle(literals::app::title);
	qRegisterMetaType<u64>("u64");
	qRegisterMetaType<usize>("usize");
	qRegisterMetaType<f128>("f128");
	connect(request, SIGNAL(offer(u64*, usize, f128, f128)), this, SLOT(accept(u64*, usize, f128, f128)));
}

MainWindow::~MainWindow(void) {
	// Response Widget
	if (placeholder) {
		central.layout->removeWidget(placeholder);
		delete placeholder;
	}
	if (response) {
		central.layout->removeWidget(response);
		delete response;
	}
	// Request Widget
	central.layout->removeWidget(request);
	delete request;
	// Central components
	delete central.layout;
	delete central.widget;
}

void MainWindow::accept(u64* values, usize size, f128 mean, f128 variance) {
	if (placeholder) {
		central.layout->removeWidget(placeholder);
		delete placeholder;
		placeholder = nullptr;
	}
	if (response) {
		central.layout->removeWidget(response);
		delete response;
	}
	response = new ResponseWidget;
	central.layout->addWidget(response, 2);
	response->analyse(values, size, mean, variance);
}
