#pragma once

#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QHBoxLayout>
#include <QComboBox>
#include <QRadioButton>
#include <QLineEdit>
#include <QPushButton>

#include <common/core/types.hpp>
#include <common/core/Timer.hpp>
#include <common/interface/prng.hpp>
#include <common/interface/OptionsWidget.hpp>
#include <interface/literals.hpp>

class RequestWidget : public QWidget {
	Q_OBJECT
public:
	RequestWidget(QWidget* const parent = nullptr);
	~RequestWidget(void);
private:
	// Timer
	Timer timer;
	// Central components
	struct {
		QVBoxLayout* layout = nullptr;
	} central;
	// Generator selection
	struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QComboBox* dropdown = nullptr;
	} generator;
	// Distribution selection
	struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QComboBox* dropdown = nullptr;
	} distribution;
	// Sequence quantity
	struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		struct {
			QRadioButton* button = nullptr;
			QLabel* prompt = nullptr;
		} fixed[3];
		struct {
			QRadioButton* button = nullptr;
			QLineEdit* line = nullptr;
		} flexible;
	} quantity;
	// Generator options
	struct {
		QVBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		OptionsWidget* widgets[literals::constants::PRNG_GENERATORS] = {};
	} generator_options;
	// Distribution options
	struct {
		QVBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		OptionsWidget* widgets[literals::constants::PRNG_DISTRIBUTIONS] = {};
	} distribution_options;
	// Generate button
	struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QPushButton* button = nullptr;
	} generate;
private slots:
	void generator_dropdown(const int index);
	void distribution_dropdown(const int index);
	void generate_button(void);
private:
	int old_generator_index = 0;
	int old_distribution_index = 0;
signals:
	void generation_request(void);
	void computations_signal(u64*, const usize, const f128, const f128);
	void offer(u64*, const usize, const f128, const f128);
private slots:
	void generation_request_handler(void);
	void computations_slot(u64*, const usize, const f128, const f128);
};
