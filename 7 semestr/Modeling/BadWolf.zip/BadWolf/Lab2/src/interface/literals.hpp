#pragma once

#include <cstdint>

#define literal static constexpr const

namespace literals::app {
	literal auto title = "Modeling - Lab 2 - PRNG: Distributions";
}

namespace literals::constants {
	literal auto flexible = 50000000ul;
	literal std::size_t quantity[] = {
		10000ul,
		5000000ul,
		10000000ul,
	};
}

namespace literals::plot {
	literal auto title = "Histogram";
	literal auto x = "Value";
	literal auto y = "Frequency";
}

#undef literal
