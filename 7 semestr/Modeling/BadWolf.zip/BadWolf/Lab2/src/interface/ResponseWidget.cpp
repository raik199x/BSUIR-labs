#include <iostream>
#include <thread>

#include <common/backend/statistics.hpp>

#include <libs/quadmath/f128.hpp>

#include <interface/literals.hpp>
#include <interface/ResponseWidget.hpp>

static constexpr const char* const outer_prompts[2] = { "Mean", "Variance", };
static constexpr const char* const inner_prompts[3] = { "Theoretical", "Real", "Deviation, %", };

ResponseWidget::ResponseWidget(QWidget* const parent) : QWidget(parent) {
	// Layouts
	central.layout = new QVBoxLayout;
	analysis.prompts.layout = new QHBoxLayout;
	analysis.layout = new QHBoxLayout;
	analysis.mean.layout = new QVBoxLayout;
	analysis.variance.layout = new QVBoxLayout;
	// Analysis
	analysis.prompts.main = new QLabel("Analysis");
	analysis.prompts.main->setAlignment(Qt::AlignCenter);
	central.layout->addWidget(analysis.prompts.main);
	usize index = 0;
	for (auto& p : analysis.prompts.other) {
		p = new QLabel(outer_prompts[index++]);
		p->setAlignment(Qt::AlignCenter);
		analysis.prompts.layout->addWidget(p, 1);
	}
	central.layout->addLayout(analysis.prompts.layout);
	index = 0;
	for (auto& v : analysis.mean.values) {
		v.layout = new QHBoxLayout;
		v.prompt = new QLabel(inner_prompts[index++]);
		v.layout->addWidget(v.prompt, 1);
		v.value = new QLineEdit("Analysing...");
		v.value->setReadOnly(true);
		v.layout->addWidget(v.value, 2);
		analysis.mean.layout->addLayout(v.layout);
	}
	analysis.layout->addLayout(analysis.mean.layout, 1);
	index = 0;
	for (auto& v : analysis.variance.values) {
		v.layout = new QHBoxLayout;
		v.prompt = new QLabel(inner_prompts[index++]);
		v.layout->addWidget(v.prompt, 1);
		v.value = new QLineEdit("Analysing...");
		v.value->setReadOnly(true);
		v.layout->addWidget(v.value, 3);
		analysis.variance.layout->addLayout(v.layout);
	}
	analysis.layout->addLayout(analysis.variance.layout, 1);
	central.layout->addLayout(analysis.layout);
	// Plot
	histogram = newEmptyPlot<u64>(literals::plot::title, literals::plot::x, literals::plot::y);
	central.layout->addWidget(histogram);
	// Central components
	setLayout(central.layout);
	qRegisterMetaType<f128>("f128");
	connect(
		this, SIGNAL(analysis_signal(const f128, const f128, const f128, const f128)),
		this, SLOT(analysis_slot(const f128, const f128, const f128, const f128))
	);
	connect(
		this, SIGNAL(plot_signal(u64*, const usize)),
		this, SLOT(plot_slot(u64*, const usize))
	);
}

ResponseWidget::~ResponseWidget(void) {
	// Plot
	central.layout->removeWidget(histogram);
	delete histogram;
	// Analysis
	for (auto& v : analysis.variance.values) {
		v.layout->removeWidget(v.value);
		delete v.value;
		v.layout->removeWidget(v.prompt);
		delete v.prompt;
		analysis.variance.layout->removeItem(v.layout);
		delete v.layout;
	}
	analysis.layout->removeItem(analysis.variance.layout);
	delete analysis.variance.layout;
	for (auto& v : analysis.mean.values) {
		v.layout->removeWidget(v.value);
		delete v.value;
		v.layout->removeWidget(v.prompt);
		delete v.prompt;
		analysis.mean.layout->removeItem(v.layout);
		delete v.layout;
	}
	analysis.layout->removeItem(analysis.mean.layout);
	delete analysis.mean.layout;
	central.layout->removeItem(analysis.layout);
	delete analysis.layout;
	for (auto& p : analysis.prompts.other) {
		analysis.prompts.layout->removeWidget(p);
		delete p;
	}
	central.layout->removeItem(analysis.prompts.layout);
	delete analysis.prompts.layout;
	central.layout->removeWidget(analysis.prompts.main);
	delete analysis.prompts.main;
	// Central components
	delete central.layout;
}

void ResponseWidget::analyse(u64* values, const usize size, const f128 mean, const f128 variance) {
	std::clog << '\n' << "[ LOG ] Launching analysis in a new thread..." << std::endl;
	std::thread analysis_thread ([=, this]() {
		const auto m = statistics::mean(values, size);
		const auto v = statistics::variance(values, size, m);
		emit analysis_signal(mean, variance, m, v);
		emit plot_signal(values, size);
	});
	analysis_thread.detach();
}

void ResponseWidget::analysis_slot(const f128 theory_mean, const f128 theory_variance, const f128 real_mean, const f128 real_variance) {
	const auto deviation_mean = static_cast<f32>(std::abs((theory_mean - real_mean) * 100 / theory_mean));
	const auto deviation_variance = static_cast<f32>(std::abs((theory_variance - real_variance) * 100 / theory_variance));
	const std::string mean[3] = {
		std::to_string(theory_mean),
		std::to_string(real_mean),
		std::to_string(deviation_mean),
	};
	const std::string variance[3] = {
		std::to_string(theory_variance),
		std::to_string(real_variance),
		std::to_string(deviation_variance),
	};
	usize index = 0;
	for (auto& val : analysis.mean.values) {
		val.value->setText(QString::fromStdString(mean[index++]));
	}
	index = 0;
	for (auto& val : analysis.variance.values) {
		val.value->setText(QString::fromStdString(variance[index++]));
	}
	std::clog << "[ LOG ] Analysis is completed!" << std::endl;
}

void ResponseWidget::plot_slot(u64* values, const usize size) {
	QCustomPlot* const plot = newCustomPlot<u64>(literals::plot::title, literals::plot::x, literals::plot::y, values, size);
	delete[] values;
	central.layout->removeWidget(histogram);
	delete histogram;
	central.layout->addWidget(histogram = plot);
	std::clog << "[ LOG ] Histogram was updated!" << std::endl;
}
