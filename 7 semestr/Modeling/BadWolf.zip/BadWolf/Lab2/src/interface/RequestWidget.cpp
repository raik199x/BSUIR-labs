#include <iostream>
#include <thread>

#include <common/math/prng.hpp>

#include <libs/Qt/metaSignature.hpp>

#include <interface/RequestWidget.hpp>
#include <interface/literals.hpp>

const static QString SEPARATOR = QString("\t\t");

RequestWidget::RequestWidget(QWidget* const parent) : QWidget(parent) {
	// Layouts
	central.layout = new QVBoxLayout;
	generator.layout = new QHBoxLayout;
	distribution.layout = new QHBoxLayout;
	quantity.layout = new QHBoxLayout;
	generator_options.layout = new QVBoxLayout;
	distribution_options.layout = new QVBoxLayout;
	generate.layout = new QHBoxLayout;
	// Generator selection
	generator.prompt = new QLabel("A. Generator:");
	generator.layout->addWidget(generator.prompt);
	generator.dropdown = new QComboBox;
	generator.dropdown->addItem(literals::request::dropdown);
	usize index = 0;
	for (const auto entity : literals::request::generators) {
		generator.dropdown->addItem(QString::number(++index) + ". " + entity);
	}
	generator.layout->addWidget(generator.dropdown);
	central.layout->addLayout(generator.layout);
	// Distribution selection
	distribution.prompt = new QLabel("B. Distribution:");
	distribution.layout->addWidget(distribution.prompt);
	distribution.dropdown = new QComboBox;
	distribution.dropdown->addItem(literals::request::dropdown);
	index = 0;
	for (const auto entity : literals::request::distributions) {
		distribution.dropdown->addItem(QString::number(++index) + ". " + entity);
	}
	distribution.layout->addWidget(distribution.dropdown);
	central.layout->addLayout(distribution.layout);
	// Sequence quantity
	quantity.prompt = new QLabel("C. Quantity:");
	central.layout->addWidget(quantity.prompt);
	index = 0;
	for (auto& fx : quantity.fixed) {
		fx.button = new QRadioButton;
		fx.button->setChecked(false);
		fx.prompt = new QLabel(QString::number(literals::constants::quantity[index++]));
		quantity.layout->addWidget(fx.button);
		quantity.layout->addWidget(fx.prompt, 1);
	}
	quantity.flexible.button = new QRadioButton;
	quantity.flexible.button->setChecked(true);
	quantity.flexible.line = new QLineEdit;
	quantity.flexible.line->setText(QString::number(literals::constants::flexible));
	quantity.layout->addWidget(quantity.flexible.button);
	quantity.layout->addWidget(quantity.flexible.line, 3);
	central.layout->addLayout(quantity.layout);
	// Generator options
	generator_options.prompt = new QLabel("D. Generator Options");
	generator_options.layout->addWidget(generator_options.prompt);
	index = 0;
	for (auto& widget : generator_options.widgets) {
		widget = new OptionsWidget(literals::request::generator_options[index], literals::request::generator_values[index], true);
		widget->hide();
		generator_options.layout->addWidget(widget);
		++index;
	}
	central.layout->addLayout(generator_options.layout);
	// Distribution options
	distribution_options.prompt = new QLabel("E. Distribution Options");
	distribution_options.layout->addWidget(distribution_options.prompt);
	index = 0;
	for (auto& widget : distribution_options.widgets) {
		widget = new OptionsWidget(literals::request::distribution_options[index], literals::request::distribution_values[index], true);
		widget->hide();
		distribution_options.layout->addWidget(widget);
		++index;
	}
	central.layout->addLayout(distribution_options.layout);
	// Generate button
	generate.prompt = new QLabel("F. Sequence Generation");
	generate.layout->addWidget(generate.prompt);
	generate.button = new QPushButton("Generate");
	generate.layout->addWidget(generate.button);
	central.layout->addLayout(generate.layout);
	// Central components
	setLayout(central.layout);
	// Widget configuration
	connect(
		generator.dropdown, SIGNAL(currentIndexChanged(int)),
		this, SLOT(generator_dropdown(const int))
	);
	connect(
		distribution.dropdown, SIGNAL(currentIndexChanged(int)),
		this, SLOT(distribution_dropdown(const int))
	);
	connect(
		generate.button, SIGNAL(clicked()),
		this, SLOT(generate_button(void))
	);
	connect(
		this, SIGNAL(generation_request(void)),
		this, SLOT(generation_request_handler(void))
	);
	qRegisterMetaType<u64*>("u64*");
	qRegisterMetaType<usize>("usize");
	qRegisterMetaType<f128>("f128");
	connect(
		this, SIGNAL(computations_signal(u64*, const usize, const f128, const f128)),
		this, SLOT(computations_slot(u64*, const usize, const f128, const f128))
	);
}

RequestWidget::~RequestWidget(void) {
	// Generate button
	generate.layout->removeWidget(generate.button);
	delete generate.button;
	generate.layout->removeWidget(generate.prompt);
	delete generate.prompt;
	central.layout->removeItem(generate.layout);
	delete generate.layout;
	// Distribution options
	for (auto& widget : distribution_options.widgets) {
		distribution_options.layout->removeWidget(widget);
		delete widget;
	}
	distribution_options.layout->removeWidget(distribution_options.prompt);
	delete distribution_options.prompt;
	central.layout->removeItem(distribution_options.layout);
	delete distribution_options.layout;
	// Generator options
	for (auto& widget : generator_options.widgets) {
		generator_options.layout->removeWidget(widget);
		delete widget;
	}
	generator_options.layout->removeWidget(generator_options.prompt);
	delete generator_options.prompt;
	central.layout->removeItem(generator_options.layout);
	delete generator_options.layout;
	// Sequence quantity
	quantity.layout->removeWidget(quantity.flexible.line);
	delete quantity.flexible.line;
	quantity.layout->removeWidget(quantity.flexible.button);
	delete quantity.flexible.button;
	for (auto& fx : quantity.fixed) {
		quantity.layout->removeWidget(fx.prompt);
		delete fx.prompt;
		quantity.layout->removeWidget(fx.button);
		delete fx.button;
	}
	central.layout->removeWidget(quantity.prompt);
	delete quantity.prompt;
	central.layout->removeItem(quantity.layout);
	delete quantity.layout;
	// Distribution selection
	distribution.layout->removeWidget(distribution.dropdown);
	delete distribution.dropdown;
	distribution.layout->removeWidget(distribution.prompt);
	delete distribution.prompt;
	central.layout->removeItem(distribution.layout);
	delete distribution.layout;
	// Generator selection
	generator.layout->removeWidget(generator.dropdown);
	delete generator.dropdown;
	generator.layout->removeWidget(generator.prompt);
	delete generator.prompt;
	central.layout->removeItem(generator.layout);
	delete generator.layout;
	// Central components
	delete central.layout;
}

void RequestWidget::generator_dropdown(const int index) {
	if (index == 0) {
		generator.dropdown->setCurrentIndex(old_generator_index);
		return;
	}
	generator_options.widgets[old_generator_index - 1]->hide();
	generator_options.prompt->show();
	generator_options.widgets[index - 1]->show();
	old_generator_index = index;
}

void RequestWidget::distribution_dropdown(const int index) {
	if (index == 0) {
		distribution.dropdown->setCurrentIndex(old_distribution_index);
		return;
	}
	distribution_options.widgets[old_distribution_index - 1]->hide();
	distribution_options.prompt->show();
	distribution_options.widgets[index - 1]->show();
	old_distribution_index = index;
}

void RequestWidget::generate_button(void) {
	if (generator.dropdown->currentIndex() == 0 || distribution.dropdown->currentIndex() == 0) {
		std::cerr << "[ERROR] Both a generator and a distribution must be specified" << std::endl;
		return;
	}
	generate.button->setDisabled(true);
	emit generation_request();
}

u64* generation_request_computations(
	prng::IDistribution<u64>* const distribution_ptr,
	prng::IGenerator<u64>* const generator_ptr,
	const usize requested_quantity
) {
	u64* results = new u64[requested_quantity];
	for (usize i = 0; i < requested_quantity; ++i) {
		results[i] = distribution_ptr->next(generator_ptr);
	}
	return results;
}

void RequestWidget::generation_request_handler(void) {
	generate.button->setText("Generating...");
	std::clog << '\n' << "[ LOG ] RequestWidget::generation_request_handler:" << std::endl;

	const auto requested_generator = generator.dropdown->currentIndex() - 1;
	const auto requested_distribution = distribution.dropdown->currentIndex() - 1;
	std::optional<usize> optional_quantity;
	for (const auto& fx : quantity.fixed)
		if (fx.button->isChecked())
			optional_quantity = fx.prompt->text().toULongLong();
	if (quantity.flexible.button->isChecked())
		optional_quantity = quantity.flexible.line->text().toULongLong();
	if (!optional_quantity.has_value()) throw std::runtime_error("Quantity must be specified");
	const auto requested_quantity = optional_quantity.value();

	std::clog << "[ LOG ] Generator:    " << literals::request::generators[requested_generator] << std::endl;
	std::clog << "[ LOG ] Distribution: " << literals::request::distributions[requested_distribution] << std::endl;
	std::clog << "[ LOG ] Quantity:     " << requested_quantity << std::endl;

	prng::IGenerator<u64>* generator_ptr = request::generator(generator_options.widgets[requested_generator], requested_generator);
	prng::IDistribution<u64>* distribution_ptr = request::distribution(distribution_options.widgets[requested_distribution], requested_distribution);

	std::clog << '\n' << "[ LOG ] Launching computations in a new thread..." << std::endl;
	timer.start();
	std::thread computations_thread ([=, this]() {
		u64* results = generation_request_computations(distribution_ptr, generator_ptr, requested_quantity);
		const f128 mean = distribution_ptr->mean();
		const f128 variance = distribution_ptr->variance();
		delete distribution_ptr;
		delete generator_ptr;
		emit computations_signal(results, requested_quantity, mean, variance);
	});
	computations_thread.detach();
}

void RequestWidget::computations_slot(u64* values, const usize quantity, const f128 mean, const f128 variance) {
	timer.stop();
	std::clog << "[ LOG ] Computations are completed!" << std::endl;
	std::clog << "[ LOG ] Duration: "
			  << timer.hours() << "h "
			  << timer.minutes() << "m "
			  << timer.seconds() << "s "
			  << timer.milliseconds() << "ms "
			  << timer.microseconds() << "us "
			  << timer.nanoseconds() << "ns"
			  << std::endl;
	generate.button->setText("Generate");
	generate.button->setEnabled(true);
	const auto meta_offer = QMetaMethod::fromSignal(&RequestWidget::offer);
	if (!isSignalConnected(meta_offer)) {
		std::cerr << "[ERROR] signal `" << metaSignature(meta_offer).toStdString() << "' is not connected to any slot" << std::endl;
		delete[] values;
		return;
	}
	emit offer(values, quantity, mean, variance);
}
