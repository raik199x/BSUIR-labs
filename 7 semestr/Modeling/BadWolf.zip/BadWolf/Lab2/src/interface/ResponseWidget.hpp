#pragma once

#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QHBoxLayout>
#include <QLineEdit>

#include <common/core/types.hpp>

#include <libs/qcustomplot/newEmptyPlot.hpp>
#include <libs/qcustomplot/newCustomPlot.hpp>

class ResponseWidget : public QWidget {
	Q_OBJECT
public:
	ResponseWidget(QWidget* const parent = nullptr);
	~ResponseWidget(void);
private:
	// Central components
	struct {
		QVBoxLayout* layout = nullptr;
	} central;
	// Analysis
	struct {
		struct {
			QLabel* main;
			QHBoxLayout* layout;
			QLabel* other[2] = {};
		} prompts;
		QHBoxLayout* layout = nullptr;
		struct {
			QLabel* prompt = nullptr;
			QVBoxLayout* layout = nullptr;
			struct {
				QHBoxLayout* layout = nullptr;
				QLabel* prompt = nullptr;
				QLineEdit* value = nullptr;
			} values[3];
		} mean, variance;
	} analysis;
	// Plot
	QCustomPlot* histogram = nullptr;
public:
	void analyse(u64* values, const usize size, const f128 mean, const f128 variance);
signals:
	void analysis_signal(const f128, const f128, const f128, const f128);
	void plot_signal(u64*, const usize);
private slots:
	void analysis_slot(const f128, const f128, const f128, const f128);
	void plot_slot(u64*, const usize);
};
