#include <interface/testing.hpp>
#include <interface/parsing.hpp>

static constexpr const f128 RHO = 0.50f64;
static constexpr const f128 PI2 = 0.45f64;
static constexpr const f128 PI3 = 0.35f64;

int main(void) {
	testing::interface();
	parsing::interface(RHO, PI2, PI3);
	return 0;
}
