#pragma once

#include <common/core/types.hpp>

typedef struct {
	f128 rho = .0f128;
	f128 pi2 = .0f128;
	f128 pi3 = .0f128;
	f128 sum = .0f128;
	f128 ticked = .0f128;
	f128 success = .0f128;
	f128 failure = .0f128;
	f128 generate = .0f128;
} ComputationsResult;
