#pragma once

#include <string>
#include <vector>

#include <common/core/types.hpp>

namespace cchar {
	static constexpr const std::string DASH = "\u2212";
	static constexpr const std::string CDOT = "\u00B7";
	static constexpr const std::string PI = "\u03C0";
	static constexpr const std::string RHO = "\u03C1";
}

#define literal static constexpr const char* const
#define numeric static constexpr const usize

namespace literals::app {
	literal title = "Modelling - Lab 3 - Queueing theory";
	literal task = "Task 10";
}

namespace literals::generators {
	literal prompt = "A. Select a generator for the geometric distribution";
}

namespace literals::options {
	literal prompt = "C. Specify the parameters for the model emulation:";
	static const std::vector<std::string> prompts = {
		cchar::RHO.c_str(),
		cchar::PI + "<sub>2</sub>",
		cchar::PI + "<sub>3</sub>",
	};
	static const std::vector<std::string> values = {
		"0.5",
		"0.45",
		"0.35",
	};
}

namespace literals::quantity {
	literal prompt = "D. Specify the quantity of ticks for the model emulation:";
	numeric default_value = 10000000lu;
}

namespace literals::emulate {
	literal prompt = "E. Run the model emulation:";
	literal button = "Emulate";
	literal process = "Emulating...";
}

#undef numeric
#undef literal
