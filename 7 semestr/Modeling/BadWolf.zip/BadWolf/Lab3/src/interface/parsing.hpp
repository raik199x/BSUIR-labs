#pragma once

#include <fstream>
#include <iostream>

#include <backend/Parsing.hpp>

#include <interface/consts.hpp>

namespace parsing {
	static constexpr const Actions<4> SKIPS = { true, true, false, false, };

	void interface(const f128 rho, const f128 pi2, const f128 pi3) {
		Parameters parameters = {
			.rho = static_cast<f64>(rho),
			.pi2 = static_cast<f64>(pi2),
			.pi3 = static_cast<f64>(pi3),
		};

		std::ifstream infile(paths::MODEL);
		if (!infile.is_open())
			throw std::runtime_error("Could not open infile");
		std::ofstream graph(paths::UML);
		if (!graph.is_open())
			throw std::runtime_error("Could not open graph file");
		std::ofstream script(paths::SCRIPT);
		if (!script.is_open())
			throw std::runtime_error("Could not open script file");
		std::ofstream logfile(paths::PARSE);
		if (!logfile.is_open())
			throw std::runtime_error("Could not open logfile");
		auto backup = std::clog.rdbuf();
		std::clog.rdbuf(logfile.rdbuf());
		Parsing<4>(parameters).run(SKIPS, infile, graph, script);
		std::clog.rdbuf(backup);
		logfile.close();
		script.close();
		graph.close();
		infile.close();

		const auto plantUML = std::string() + "plant""uml " + paths::UML + " -o " + paths::IMGS;
		if (std::system(plantUML.c_str()) != 0)
			throw std::runtime_error("[ERROR] Unable to generate PlantUML diagram!");

		const auto octave = std::string() + "octave " + paths::SCRIPT + " > " + paths::OCTAVE;
		if (std::system(octave.c_str()) != 0)
			throw std::runtime_error("[ERROR] Execution of Octave script failed!");
	}
}
