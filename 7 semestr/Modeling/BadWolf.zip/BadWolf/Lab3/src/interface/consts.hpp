#pragma once

#include <backend/Actions.hpp>

static constexpr const Actions<4> SKIPS = { true, true, false, false, };

namespace paths {
	static constexpr const auto MODEL   = "logs/Model.log";
	static constexpr const auto PARSE   = "logs/Parse.log";
	static constexpr const auto UML     = "scripts/Plant""UML.plant""uml";
	static constexpr const auto SCRIPT  = "scripts/Octave.mn";
	static constexpr const auto IMGS    = "../imgs";
	static constexpr const auto DRAWING = "scripts/Draw""io.draw""io";
	static constexpr const auto SCHEME  = "imgs/Scheme.png";
	static constexpr const auto GRAPH   = "imgs/Graph.png";
	static constexpr const auto OCTAVE  = "logs/Octave.log";
}
