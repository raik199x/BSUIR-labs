#pragma once

#include <fstream>
#include <iostream>
#include <stdexcept>

#include <backend/Actions.hpp>
#include <backend/Device.hpp>
#include <backend/Testing.hpp>

#include <interface/consts.hpp>

namespace testing {
	static constexpr const std::array<Device::Policy, 4> POLICIES = {
		Device::Policy::DISCARD,
		Device::Policy::SUSPEND,
		Device::Policy::DISCARD,
		Device::Policy::UNKNOWN,
	};

	void interface(void) {
		std::ofstream logfile(paths::MODEL);
		if (!logfile.is_open())
			throw std::runtime_error("Could not open logfile");
		auto backup = std::clog.rdbuf();
		std::clog.rdbuf(logfile.rdbuf());
		Testing<4>().full(POLICIES, SKIPS);
		std::clog.rdbuf(backup);
		logfile.close();
	}
}
