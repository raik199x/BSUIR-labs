#pragma once

#include <ranges>
#include <ostream>

#include <common/core/types.hpp>

#include <backend/Device.hpp>
#include <backend/Actions.hpp>

template <const usize N>
class Model {
public:
	Model(const Devices<N>& devices) : devices(devices) {}
	Model(void) = default;
	~Model(void) = default;
private:
	Devices<N> devices = {};
public:
	friend std::ostream& operator<<(std::ostream& os, const Model& model) {
		for (const auto& device : model.devices) {
			os << device.state;
		}
		return os;
	}
	void shift(const Actions<N>& shift) {
		success = failure = 0lu;
		for (usize index = 0; index < N; ++index) {
			const auto i = N - 1 - index;
			auto& device = devices[i];
			const auto action = shift[i];
			if (device.state == Device::State::FREE || action == false) {
				continue;
			}
			if (index == 0) {
				device.state = Device::State::FREE;
				++success;
				continue;
			}
			auto& next = devices[i + 1];
			switch (next.state) {
			case Device::State::FREE: {
				next.state = Device::State::BUSY;
				device.state = Device::State::FREE;
			} break;
			case Device::State::BUSY: {
				switch (device.policy) {
				case Device::Policy::SUSPEND: {
					continue;
				} break;
				case Device::Policy::DISCARD: {
					device.state = Device::State::FREE;
					++failure;
				} break;
				default: throw std::runtime_error("Invalid device policy");
				};
			} break;
			default: throw std::runtime_error("Invalid device state");
			};
		}
	}
	Devices<N> get_devices(void) const {
		return devices;
	}
	void set_devices(const Devices<N>& devices) {
		this->devices = devices;
	}
	usize success = 0ul;
	usize failure = 0ul;
};
