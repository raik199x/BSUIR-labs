#pragma once

#include <ostream>
#include <array>

#include <common/core/types.hpp>

struct Device {
	enum class State {
		FREE,
		BUSY,
		UNKNOWN,
	};
	Device::State state = Device::State::FREE;
	enum class Policy {
		SUSPEND,
		DISCARD,
		UNKNOWN,
	};
	Device::Policy policy = Device::Policy::SUSPEND;
};

template <const usize N>
using Devices = std::array<Device, N>;

std::ostream& operator<<(std::ostream& os, const Device::State& state);
