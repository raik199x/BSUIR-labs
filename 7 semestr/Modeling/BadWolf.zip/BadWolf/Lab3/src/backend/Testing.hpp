#pragma once

#include <ranges>

#include <common/core/types.hpp>
#include <common/core/consts.hpp>

#include <backend/Actions.hpp>
#include <backend/Model.hpp>

template <const usize N>
class Testing {
public:
	Testing(void) = default;
	~Testing(void) = default;
	static void test(const Model<N>& model, const Actions<N>& shift) {
		Model<N> result = model;
		std::clog << result << ' '  << shift;
		result.shift(shift);
		std::clog << ' ' << result << endl;
	}
public:
	static void full(const std::array<Device::Policy, N>& policies, const Actions<N>& skips) {
		std::clog << "--- Full transition table for the model ---\n";
		for (const auto states : std::ranges::iota_view{0, 1 << N}) {
			const Actions<N> initial_states = to_actions<N>(states);
			for (const auto triggers : std::ranges::iota_view{0, 1 << N}) {
				Devices<N> devices = {};
				for (const auto& [device, initial_state, policy] : std::ranges::views::zip(devices, initial_states, policies)) {
					device.state = initial_state ? Device::State::BUSY : Device::State::FREE;
					device.policy = policy;
				}
				const auto shift_triggers = to_actions<N>(triggers);
				bool flag = false;
				for (const auto& [shift_trigger, skip] : std::ranges::views::zip(shift_triggers, skips)) {
					if (skip && (shift_trigger == false)) {
						flag = true;
						break;
					}
				}
				if (flag) {
					continue;
				}
				test(Model<N>(devices), shift_triggers);
			}
		}
	}
};
