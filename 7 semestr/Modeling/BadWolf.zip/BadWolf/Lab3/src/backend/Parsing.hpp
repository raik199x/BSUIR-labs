#pragma once

#include <map>
#include <array>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <optional>
#include <numeric>
#include <algorithm>

#include <common/core/types.hpp>
#include <common/core/consts.hpp>

#include <interface/literals.hpp>

#include <backend/Actions.hpp>

static constexpr const std::string_view DASHED_ARROW = "TO";
static constexpr const std::string_view FIXING_ARROW = "FX";
static constexpr const std::string_view TITLE = literals::app::title;

struct Parameters {
	f64 rho;
	f64 pi2;
	f64 pi3;
};

template <const usize N>
class Parsing {
	using Vector = std::vector<std::string>;
	using Links = std::array<std::map<std::string, std::string>, 1 << (N - 1u)>;
	using Matrix = std::array<std::array<std::string, 1 << (N - 1u)>, 1 << (N - 1u)>;
public:
	Parsing(const Parameters& parameters) : parameters(parameters) {}
	~Parsing(void) = default;
private:
	Parameters parameters;
	template <typename T>
	static void unique_push(std::vector<T>& vector, const T& value) {
		if (std::find(vector.begin(), vector.end(), value) == vector.end()) {
			vector.push_back(value);
		}
	}
	static std::optional<usize> diff_by_index(const std::string& sa, const std::string& sb) {
		const usize size = sa.length();
		if (size != sb.length()) {
			return std::nullopt;
		}
		std::optional<usize> result = std::nullopt;
		for (usize index = 0; index < size; ++index) {
			if (sa.at(index) != sb.at(index)) {
				if (result.has_value()) {
					return std::nullopt;
				}
				result = index;
			}
		}
		return result;
	}
	static Vector minimize(const Vector& values) {
		Vector result;
		const usize size = values.size();
		for (usize i = 0; i < size; ++i) {
			for (usize j = 0; j < size; ++j) {
				if (i == j) { continue; }
				const auto idx = diff_by_index(values.at(i), values.at(j));
				if (!idx.has_value()) { continue; }
				auto tmp = values.at(i);
				tmp.at(idx.value()) = '-';
				unique_push(result, tmp);
				for (usize k = 0; k < size; ++k) {
					if (k == i || k == j) { continue; }
					unique_push(result, values.at(k));
				}
				return result;
			}
		}
		return values;
	}
	static std::string report(const std::string& value, const std::string& name, const std::string& minus) {
		if (value == "0") {
			return name;
		}
		else if (value == "1") {
			return "(1 " + minus + " " + name + ")";
		}
		return "";
	}
	static void draw(std::ofstream& graph, const Links& links) {
		graph << "' " << TITLE << " - PlantUML script" << endl;
		graph << "' ""The reasoning: We need to build a graph of states for the model" << endl << endl;
		graph << "@" << "start" << "uml Graph" << endl << endl;
		graph << "!define " << DASHED_ARROW << " <-[dashed]" << endl;
		graph << "!define " << FIXING_ARROW << " <-[hidden]" << endl << endl;
		for (const auto index : std::ranges::iota_view{0u, (1u << (N - 1u)) - 1u}) {
			graph << to_actions<N - 1u>(index) << ' ' << FIXING_ARROW << ' ' << to_actions<N - 1u>(index + 1u) << endl;
		}
		graph << endl;
		for (const auto& link : links) {
			for (const auto& [key, value] : link) {
				if (key.find(DASHED_ARROW) == std::string::npos) {
					continue;
				}
				graph << key << " : " << value << endl;
			}
			for (const auto& [key, value] : link) {
				if (key.find(DASHED_ARROW) != std::string::npos) {
					continue;
				}
				graph << key << " : " << value << endl;
			}
			graph << endl;
		}
		graph << "@" << "end" << "uml" << endl;
	}
	void calculate(std::ofstream& calc, const Matrix matrix) const {
		calc << "% " << TITLE << " - Octave script" << endl;
		calc << "% ""The reasoning: We want to automaticaly solve the system of linear equations for the model" << endl << endl;
		calc << "% ""Constants (parameters)" << endl;
		calc << "rho = " << parameters.rho << endl;
		calc << "pi2 = " << parameters.pi2 << endl;
		calc << "pi3 = " << parameters.pi3 << endl << endl;
		calc << "% ""Coefficient matrix" << endl;
		calc << "A = [" << endl;
		std::array<usize, 1 << (N - 1u)> lengths = {};
		for (const auto i : std::ranges::iota_view{0u, 1u << (N - 1u)}) {
			for (const auto j : std::ranges::iota_view{0u, 1u << (N - 1u)}) {
				const auto length = matrix.at(i).at(j).length();
				lengths.at(j) = std::max(lengths.at(j), length);
			}
		}
		for (const auto i : std::ranges::iota_view{0u, 1u << (N - 1u)}) {
			calc << '\t';
			for (const auto j : std::ranges::iota_view{0u, 1u << (N - 1u)}) {
				std::string value = matrix.at(i).at(j);
				if (value.empty()) {
					value = "0";
				}
				calc << std::left << std::setw(lengths.at(j)) << value << ", ";
			}
			calc << ';' << endl;
		}
		calc << '\t';
		for (const auto j : std::ranges::iota_view{0u, 1u << (N - 1u)}) {
			calc << std::left << std::setw(lengths.at(j)) << 1 << ", ";
		}
		calc << ';' << endl << ']' << endl << endl;
		calc << "% ""Right-hand side vector" << endl;
		calc << "B = [" << endl;
		for (usize i = 0; i < 1u << (N - 1u); ++i) {
			calc << '\t' << std::left << std::setw(lengths.at(0)) << 0 << ", ;" << endl;
		}
		calc << '\t' << std::left << std::setw(lengths.at(0)) << 1 << ", ;" << endl;
		calc << ']' << endl << endl;
		calc << "% ""Solve the system" << endl;
		calc << "X = A \\ B" << endl << endl;
		calc << "% ""Checksum" << endl;
		calc << "Checksum = sum(X)" << endl << endl;
		calc << "% ""Aliases" << endl;
		for (usize i = 0; i < 1u << (N - 1u); ++i) {
			calc << 'P' << to_actions<3>(i) << " = X(" << (i + 1) << ')' << endl;
		}
		calc << endl << "% ""Graph-specific parameters" << endl;
		calc << "K1 = P010 + P011 + P110 + P111" << endl;
		calc << "K2 = P001 + P011 + P101 + P111" << endl;
		calc << "A = K2 * (1 - pi3)" << endl;
		calc << "PBlock = 0" << endl;
		calc << "lambda = (1 - rho) * (1 - PBlock)" << endl;
		calc << "Q = A / lambda" << endl;
		calc << "PDenial = (1 - Q)" << endl;
		calc << "LQueue = ";
		for (usize i = 0; i < 1u << (N - 1u); ++i) {
			const auto state = to_actions<3>(i);
			calc << (i == 0 ? "" : " + ") << "(P" << state << " * " << (state.at(0) ? '1' : '0') << ')';
		}
		calc << endl << "LSystem = ";
		for (usize i = 0; i < 1u << (N - 1u); ++i) {
			const auto state = to_actions<3>(i);
			const usize counter = std::accumulate(state.begin(), state.end(), 0lu);
			calc << (i == 0 ? "" : " + ") << "(P" << state << " * " << counter << ')';
		}
		calc << endl << "WQueue = LQueue / lambda" << endl << "WSystem = LSystem / lambda" << endl;
	}
	std::array<Vector, 1 << (N - 1u)> values;
public:
	void run(const Actions<N>& skips, std::ifstream& file, std::ofstream& graph, std::ofstream& calc) {
		Vector lines;
		std::string header;
		std::getline(file, header);
		// Read file -> lines to parse
		while (!file.eof()) {
			std::string line;
			std::getline(file, line);
			if (line.empty())
				continue;
			unique_push(lines, line);
		}
		// Split lines by the state value (first N chars)
		for (const auto& line : lines) {
			bool pushed = false;
			for (const auto index : std::ranges::iota_view{0u, 1u << (N - 1u)}) {
				std::stringstream state1, state2;
				state1 << to_actions<N>(index);
				state2 << to_actions<N>(index + (1u << (N - 1u)));
				if (line.starts_with(state1.str()) || line.starts_with(state2.str()) ) {
					unique_push(values.at(index), line);
					pushed = true;
					break;
				}
			}
			if (!pushed) {
				throw std::logic_error("Failed to find a spot for `" + line + "'.");
			}
		}
		// Minimize the boolean functions if possible
		for (const auto index : std::ranges::iota_view{0u, 1u << (N - 1u)}) {
			bool flag = true;
			Vector buffer;
			while (flag) {
				buffer = minimize(values.at(index));
				flag = values.at(index).size() != buffer.size();
				values.at(index) = buffer;
			}
		}
		// Report minimized values
		std::clog << "--- Minimization of the transition table ---" << endl;
		for (const auto index : std::ranges::iota_view{0u, 1u << (N - 1u)}) {
			std::clog << "Model state " << index << ":\n";
			for (const auto& line : values.at(index)) {
				std::clog << line << endl;
			}
		}

		// Parse values
		Links links;
		Matrix matrix;
		for (const auto index : std::ranges::iota_view{0u, 1u << (N - 1u)}) {
			for (const auto& line : values.at(index)) {
				const auto& p_action = line.substr(0u, 1u);
				const auto& s_states = line.substr(1u, N - 1u);
				const auto& pi_actions = line.substr(N + 1u, N);
				const auto& r_states = line.substr(2u * N + 3u, N - 1u);
				const auto& signature = r_states + ' ' + (r_states == s_states ? std::string(DASHED_ARROW) : "<-") +' ' + s_states;
				auto& link = links.at(index);
				usize idx = 0;

				std::string report1 = report(p_action, cchar::RHO, cchar::DASH);
				std::string report2 = report(p_action, "rho", "-");
				for (const auto& action : pi_actions) {
					if (!skips.at(idx)) {
						const auto& tmp1 = report(std::string() + action, cchar::PI + "<sub>" + std::to_string(idx) + "</sub>", cchar::DASH);
						const auto& tmp2 = report(std::string() + action, "pi" + std::to_string(idx), "-");
						if (!report1.empty() && !tmp1.empty()) {
							report1 += ' ' + cchar::CDOT + ' ';
						}
						if (!report2.empty() && !tmp2.empty()) {
							report2 += " * ";
						}
						report1 += tmp1;
						report2 += tmp2;
					}
					idx++;
				}

				if (link.find(signature) == link.end()) {
					link.emplace(signature, report1);
				} else {
					link.at(signature) += " + " + report1;
				}

				Actions<N - 1u> s_actions, r_actions;
				for (const auto k : std::ranges::iota_view{0u, N - 1u}) {
					s_actions.at(k) = s_states.at(k) - '0';
					r_actions.at(k) = r_states.at(k) - '0';
				}
				auto& cell = matrix.at(from_actions<N - 1u>(r_actions)).at(from_actions<N - 1u>(s_actions));
				if (cell.empty()) {
					cell = report2;
				} else {
					cell += " + " + report2;
				}
			}
		}
		draw(graph, links);

		for (const auto i : std::ranges::iota_view{0u, 1u << (N - 1u)}) {
			auto& cell = matrix.at(i).at(i);
			if (!cell.empty()) {
				cell += " + ";
			}
			cell += "(-1)";
		}
		calculate(calc, matrix);
	}
};
