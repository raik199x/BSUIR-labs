#pragma once

#include <array>

#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QHBoxLayout>
#include <QPushButton>
#include <QComboBox>

#include <common/core/Timer.hpp>
#include <common/interface/OptionsWidget.hpp>
#include <common/interface/ImageWidget.hpp>
#include <common/interface/prng.hpp>

#include <interface/types.hpp>

class RequestWidget : public QWidget {
	Q_OBJECT
public:
	RequestWidget(QWidget* const parent = nullptr);
	~RequestWidget(void);
private:
	// Timer
	Timer timer;
	// Central components
	struct {
		QVBoxLayout* layout = nullptr;
	} central;
	// Scheme
	struct {
		ImageWidget* widget = nullptr;
	} scheme;
	// Dropdown
	struct {
		int index;
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QComboBox* menu = nullptr;
	} dropdown;
	// Generators
	std::array<OptionsWidget*, literals::constants::PRNG_GENERATORS> generators = {};
	// Options
	struct {
		QLabel* prompt = nullptr;
		OptionsWidget* widget = nullptr;
	} options;
	// Quantity
	struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QLineEdit* line = nullptr;
	} quantity;
	// Emulate button
	struct {
		QHBoxLayout* layout = nullptr;
		QLabel* prompt = nullptr;
		QPushButton* button = nullptr;
	} emulate;
private:
	ComputationsResult* computations_function(prng::IGenerator<u64>* const generator_ptr, usize ticks, const f128 rho, const f128 pi2, const f128 pi3);
signals:
	void computations_signal(ComputationsResult*);
	void offer(ComputationsResult*);
private slots:
	void emulate_slot(void);
	void computations_slot(ComputationsResult*);
	void dropdown_slot(int);
};
