#pragma once

#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QPixmap>
#include <QScrollArea>

#include <common/interface/ImageWidget.hpp>

#include <interface/types.hpp>

class DrawingWidget : public QWidget {
	Q_OBJECT
public:
	DrawingWidget(QWidget* const parent = nullptr);
	~DrawingWidget(void);
private:
	// Central components
	struct {
		QVBoxLayout* layout = nullptr;
	} central;
	// Images
	struct {
		ImageWidget* widget = nullptr;
	} graph;
private:
	void clear(void);
public:
	void draw(void);
};
