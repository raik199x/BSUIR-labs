#include <iostream>

#include <common/core/consts.hpp>

#include <interface/consts.hpp>

#include <frontend/DrawingWidget.hpp>

DrawingWidget::DrawingWidget(QWidget* const parent) : QWidget(parent) {
	// Layouts
	central.layout = new QVBoxLayout;
	// Central components
	setLayout(central.layout);
}

DrawingWidget::~DrawingWidget(void) {
	// Images
	clear();
	// Central components
	delete central.layout;
}

void DrawingWidget::clear(void) {
	if (graph.widget != nullptr) {
		central.layout->removeWidget(graph.widget);
		delete graph.widget;
	}
}

void DrawingWidget::draw(void) {
	clear();
	graph.widget = new ImageWidget;
	graph.widget->open("Graph of transitions", paths::GRAPH);
	central.layout->addWidget(graph.widget);
}
