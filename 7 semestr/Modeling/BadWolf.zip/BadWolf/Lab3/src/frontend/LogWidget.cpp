#include <fstream>
#include <sstream>
#include <iostream>

#include <libs/quadmath/f128.hpp>

#include <interface/consts.hpp>

#include <frontend/LogWidget.hpp>

LogWidget::LogWidget(QWidget* const parent) : QWidget(parent) {
	// Layouts
	central.layout = new QVBoxLayout;
	// Central components
	setLayout(central.layout);
}

LogWidget::~LogWidget(void) {
	// Q & Wc
	clear();
	// Central components
	delete central.layout;
}

void LogWidget::clear(void) {
	// Wc
	if (Wc.widget != nullptr) {
		central.layout->removeWidget(Wc.widget);
		delete Wc.widget;
		central.layout->removeWidget(Wc.prompt);
		delete Wc.prompt;
	}
	// Q
	if (Q.widget != nullptr) {
		central.layout->removeWidget(Q.widget);
		delete Q.widget;
		central.layout->removeWidget(Q.prompt);
		delete Q.prompt;
	}
}

void LogWidget::display(ComputationsResult* const result) {
	std::ifstream octave(paths::OCTAVE);
	if (!octave.is_open()) {
		std::cerr << "[ERROR] File `" << paths::OCTAVE << "' cannot be opened." << std::endl;
		delete result;
		return;
	}
	std::stringstream ss;
	ss << octave.rdbuf();
	std::string buffer = ss.str();
	octave.close();
	clear();
	const std::vector<std::string> prompts = { "Theoretical", "Real", "Deviation, %", };
	const usize startQ = buffer.find("Q = ");
	const usize finishQ = buffer.find("PDenial");
	if (startQ == std::string::npos || finishQ == std::string::npos) {
		throw std::runtime_error("Failed to parse `" + std::string(paths::OCTAVE) + "' log file");
	}
	const f128 tQ = std::stof128(buffer.substr(startQ + 4u, finishQ - startQ - 4u - 1u));
	const f128 lambda = 1.0f128 - result->rho;
	const f128 A = result->success / result->ticked;
	const f128 rQ = A / lambda;
	const f32 dQ = static_cast<f32>(std::abs((tQ - rQ) * 100 / tQ));;
	const usize startWc = buffer.find("WSystem");
	const usize finishWc = buffer.find("\n");
	if (startWc == std::string::npos || finishWc == std::string::npos) {
		throw std::runtime_error("Failed to parse `" + std::string(paths::OCTAVE) + "' log file");
	}
	const f128 tWc = std::stof128(buffer.substr(startWc + 10u, finishWc - startWc - 10u - 1u));
	const f128 LSystem = result->sum / result->ticked;
	const f128 rWc = LSystem / lambda;
	const f32 dWc = static_cast<f32>(std::abs((tWc - rWc) * 100 / tWc));
	const std::vector<std::string> valuesQ = { std::to_string(tQ), std::to_string(rQ), std::to_string(dQ), };
	const std::vector<std::string> valuesWc = { std::to_string(tWc), std::to_string(rWc), std::to_string(dWc), };
	// Q
	Q.prompt = new QLabel("Q");
	central.layout->addWidget(Q.prompt);
	Q.widget = new OptionsWidget(prompts, valuesQ, true);
	central.layout->addWidget(Q.widget);
	// Wc
	Wc.prompt = new QLabel("W<sub>c</sub>");
	central.layout->addWidget(Wc.prompt);
	Wc.widget = new OptionsWidget(prompts, valuesWc, true);
	central.layout->addWidget(Wc.widget);
	delete result;
}
