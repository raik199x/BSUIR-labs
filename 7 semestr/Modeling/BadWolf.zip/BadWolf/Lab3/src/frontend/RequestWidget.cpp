#include <thread>

#include <libs/quadmath/f128.hpp>
#include <libs/Qt/metaSignature.hpp>

#include <interface/consts.hpp>
#include <interface/literals.hpp>
#include <interface/testing.hpp>
#include <interface/parsing.hpp>

#include <frontend/RequestWidget.hpp>

RequestWidget::RequestWidget(QWidget* const parent) : QWidget(parent) {
	// Layouts
	central.layout = new QVBoxLayout;
	dropdown.layout = new QHBoxLayout;
	quantity.layout = new QHBoxLayout;
	emulate.layout = new QHBoxLayout;
	// Central components
	setLayout(central.layout);
	// Scheme
	const auto command = std::string() + "draw""io " + paths::DRAWING + " -x -p 1 -f png -o " + paths::SCHEME;
	if (std::system(command.c_str()) != 0)
		throw std::runtime_error("[ERROR] Failed to create `" + std::string(paths::DRAWING) + "' file");
	scheme.widget = new ImageWidget;
	scheme.widget->open(literals::app::task, paths::SCHEME);
	central.layout->addWidget(scheme.widget);
	// Dropdown
	dropdown.prompt = new QLabel(literals::generators::prompt);
	dropdown.layout->addWidget(dropdown.prompt);
	dropdown.menu = new QComboBox;
		dropdown.menu->addItem(literals::request::dropdown);
	usize k = 0u;
	for (const auto& generator : literals::request::generators) {
		dropdown.menu->addItem(QString::number(++k) + ". " + generator);
	}
	dropdown.layout->addWidget(dropdown.menu);
	central.layout->addLayout(dropdown.layout);
	// Generators
	for (usize i = 0; i < literals::constants::PRNG_GENERATORS; ++i) {
		generators.at(i) = new OptionsWidget(
			literals::request::generator_options[i],
			literals::request::generator_values[i],
			true
		);
		generators.at(i)->hide();
		central.layout->addWidget(generators.at(i));
	}
	// Options
	options.prompt = new QLabel(literals::options::prompt);
	central.layout->addWidget(options.prompt);
	options.widget = new OptionsWidget(literals::options::prompts, literals::options::values, true);
	central.layout->addWidget(options.widget);
	// Quantity
	quantity.prompt = new QLabel(literals::quantity::prompt);
	quantity.layout->addWidget(quantity.prompt, 1);
	quantity.line = new QLineEdit(QString::number(literals::quantity::default_value));
	quantity.layout->addWidget(quantity.line, 1);
	central.layout->addLayout(quantity.layout);
	// Emulate button
	emulate.prompt = new QLabel(literals::emulate::prompt);
	emulate.layout->addWidget(emulate.prompt, 1);
	emulate.button = new QPushButton(literals::emulate::button);
	emulate.layout->addWidget(emulate.button, 1);
	central.layout->addLayout(emulate.layout);
	// Widget configuration
	connect(
		dropdown.menu,
		SIGNAL(currentIndexChanged(int)),
		this,
		SLOT(dropdown_slot(int))
	);
	connect(
		emulate.button,
		SIGNAL(clicked(void)),
		this,
		SLOT(emulate_slot(void))
	);
	qRegisterMetaType<f128>("f128");
	qRegisterMetaType<ComputationsResult>("ComputationsResult");
	connect(
		this,
		SIGNAL(computations_signal(ComputationsResult*)),
		this,
		SLOT(computations_slot(ComputationsResult*))
	);
}

RequestWidget::~RequestWidget(void) {
	// Emulate button
	emulate.layout->removeWidget(emulate.button);
	delete emulate.button;
	emulate.layout->removeWidget(emulate.prompt);
	delete emulate.prompt;
	central.layout->removeItem(emulate.layout);
	delete emulate.layout;
	// Quantity
	quantity.layout->removeWidget(quantity.line);
	delete quantity.line;
	quantity.layout->removeWidget(quantity.prompt);
	delete quantity.prompt;
	central.layout->removeItem(quantity.layout);
	delete quantity.layout;
	// Options
	central.layout->removeWidget(options.widget);
	delete options.widget;
	central.layout->removeWidget(options.prompt);
	delete options.prompt;
	// Generators
	for (const auto& generator : generators) {
		central.layout->removeWidget(generator);
		delete generator;
	}
	// Dropdown
	dropdown.layout->removeWidget(dropdown.menu);
	delete dropdown.menu;
	dropdown.layout->removeWidget(dropdown.prompt);
	delete dropdown.prompt;
	central.layout->removeItem(dropdown.layout);
	delete dropdown.layout;
	// Scheme
	central.layout->removeWidget(scheme.widget);
	delete scheme.widget;
	// Central components
	delete central.layout;
}

void RequestWidget::emulate_slot(void) {
	if (dropdown.menu->currentIndex() == 0) {
		std::clog << "[ERROR] Generator must be specified before the start of an emulation" << std::endl;
		return;
	}
	emulate.button->setDisabled(true);
	emulate.button->setText(literals::emulate::process);
	#define find_option(index) options.widget->option(literals::options::prompts[index])
	const f128 rho = std::stof128(find_option(0).toString().toStdString());
	const f128 pi2 = std::stof128(find_option(1).toString().toStdString());
	const f128 pi3 = std::stof128(find_option(2).toString().toStdString());
	#undef find_option
	const usize ticks = quantity.line->text().toULongLong();
	const auto generator_ptr = request::generator(generators.at(dropdown.index), dropdown.index);

	std::clog << '\n' << "[ LOG ] Launching computations in a new thread..." << std::endl;
	timer.start();
	std::thread computations_thread ([=, this]() {
		ComputationsResult* const result = computations_function(generator_ptr, ticks, rho, pi2, pi3);
		delete generator_ptr;
		emit computations_signal(result);
	});
	computations_thread.detach();
}

ComputationsResult* RequestWidget::computations_function(prng::IGenerator<u64>* const generator_ptr, const usize ticks, const f128 rho, const f128 pi2, const f128 pi3) {
	testing::interface();
	parsing::interface(rho, pi2, pi3);
	ComputationsResult* const result = new ComputationsResult;
	result->rho = rho;
	result->pi2 = pi2;
	result->pi3 = pi3;
	Device source0  = { .state = Device::State::FREE, .policy = Device::Policy::DISCARD, };
	Device queue1   = { .state = Device::State::FREE, .policy = Device::Policy::SUSPEND, };
	Device channel2 = { .state = Device::State::FREE, .policy = Device::Policy::DISCARD, };
	Device channel3 = { .state = Device::State::FREE, .policy = Device::Policy::UNKNOWN, };
	Model<4> model = {{source0, queue1, channel2, channel3}};
	#define normal(value) ((value) * std::numeric_limits<u64>::max())
	for (usize i = 0 ; i < ticks; ++i) {
		Devices<4> devs = model.get_devices();
		if (generator_ptr->next() > normal(rho)) {
			devs.at(0).state = Device::State::BUSY;
			++result->generate;
		}
		model.set_devices(devs);
		Actions<4> shift = {true, true, false, false};
		if (generator_ptr->next() > normal(pi2)) {
			shift.at(2) = true;
		}
		if (generator_ptr->next() > normal(pi3)) {
			shift.at(3) = true;
		}
		model.shift(shift);
		devs = model.get_devices();
		++result->ticked;
		result->success += model.success;
		result->failure += model.failure;
		for (const auto dev : devs) {
			result->sum += (dev.state == Device::State::BUSY ? 1 : 0);
		}
	}
	return result;
}

void RequestWidget::computations_slot(ComputationsResult* result) {
	timer.stop();
	std::clog << "[ LOG ] Computations are completed!" << std::endl;
	std::clog << "[ LOG ] Duration: "
			  << timer.hours() << "h "
			  << timer.minutes() << "m "
			  << timer.seconds() << "s "
			  << timer.milliseconds() << "ms "
			  << timer.microseconds() << "us "
			  << timer.nanoseconds() << "ns"
			  << std::endl;
	emulate.button->setEnabled(true);
	emulate.button->setText(literals::emulate::button);
	const auto meta_offer = QMetaMethod::fromSignal(&RequestWidget::offer);
	if (!isSignalConnected(meta_offer)) {
		std::cerr << "[ERROR] signal `" << metaSignature(meta_offer).toStdString() << "' is not connected to any slot" << std::endl;
		delete result;
		return;
	}
	emit offer(result);
}

void RequestWidget::dropdown_slot(int index) {
	if (index == 0) {
		dropdown.menu->setCurrentIndex(dropdown.index + 1u);
		return;
	}
	--index;
	generators.at(dropdown.index)->hide();
	generators.at(index)->show();
	dropdown.index = index;
}
