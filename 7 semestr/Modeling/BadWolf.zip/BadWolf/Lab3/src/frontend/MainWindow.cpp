#include <interface/literals.hpp>

#include <frontend/MainWindow.hpp>

MainWindow::MainWindow(QWidget* const parent) : QMainWindow(parent) {
	// Widget and layouts
	central.widget = new QWidget;
	central.layout = new QHBoxLayout;
	left.layout = new QVBoxLayout;
	// Central components
	central.widget->setLayout(central.layout);
	setCentralWidget(central.widget);
	// Left side
	left.request = new RequestWidget;
	left.layout->addWidget(left.request, 1);
	left.log = new LogWidget;
	left.layout->addWidget(left.log, 1);
	central.layout->addLayout(left.layout, 3);
	// Right side
	drawing = new DrawingWidget;
	central.layout->addWidget(drawing, 2);
	// Window configuration
	setWindowTitle(literals::app::title);
	qRegisterMetaType<ComputationsResult>("ComputationsResult");
	connect(
		left.request,
		SIGNAL(offer(ComputationsResult*)),
		this,
		SLOT(accept(ComputationsResult*))
	);
}

MainWindow::~MainWindow(void) {
	// Right side
	central.layout->removeWidget(drawing);
	delete drawing;
	// Left side
	left.layout->removeWidget(left.log);
	delete left.log;
	left.layout->removeWidget(left.request);
	delete left.request;
	central.layout->removeItem(left.layout);
	delete left.layout;
	// Central components
	delete central.layout;
	delete central.widget;
}

#include <iostream>
#include <libs/quadmath/f128.hpp>

void MainWindow::accept(ComputationsResult* result) {
	central.layout->removeWidget(drawing);
	delete drawing;
	drawing = new DrawingWidget;
	central.layout->addWidget(drawing, 2);
	drawing->draw();
	left.log->display(result);
}
