#pragma once

#include <QMainWindow>
#include <QHBoxLayout>
#include <QVBoxLayout>

#include <common/core/types.hpp>

#include <frontend/RequestWidget.hpp>
#include <frontend/LogWidget.hpp>
#include <frontend/DrawingWidget.hpp>

class MainWindow : public QMainWindow {
	Q_OBJECT
public:
	MainWindow(QWidget* const parent = nullptr);
	~MainWindow(void);
private:
	// Central components
	struct {
		QWidget* widget = nullptr;
		QHBoxLayout* layout = nullptr;
	} central;
	// Left side
	struct {
		QVBoxLayout* layout = nullptr;
		RequestWidget* request = nullptr;
		LogWidget* log = nullptr;
	} left;
	// Right side
	DrawingWidget* drawing = nullptr;
private slots:
	void accept(ComputationsResult*);
};
