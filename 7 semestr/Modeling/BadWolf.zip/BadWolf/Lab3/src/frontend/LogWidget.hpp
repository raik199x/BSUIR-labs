#pragma once

#include <QWidget>
#include <QHBoxLayout>
#include <QLabel>

#include <common/interface/OptionsWidget.hpp>

#include <interface/types.hpp>

class LogWidget : public QWidget {
	Q_OBJECT
public:
	LogWidget(QWidget* const parent = nullptr);
	~LogWidget(void);
private:
	// Central components
	struct {
		QVBoxLayout* layout = nullptr;
	} central;
	// Q & Wc
	struct {
		QLabel* prompt = nullptr;
		OptionsWidget* widget = nullptr;
	} Q;
	struct {
		QLabel* prompt = nullptr;
		OptionsWidget* widget = nullptr;
	} Wc;
	void clear(void);
public:
	void display(ComputationsResult* const result);
};
